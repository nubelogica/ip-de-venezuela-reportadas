import { useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Copy,
  Download,
  ExternalLink,
  Search,
  ShieldOff,
  ShieldAlert,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { lookupIp } from "@/lib/lookup";
import { buildBlocklist, downloadText, EXPORT_FORMATS } from "@/lib/export-blocklist";
import {
  BOTNET_CATEGORY_IDS,
  IPV4_RE,
  categoryTotals,
  formatReports,
  hottestPrefixes,
  ispLabel,
  formatStamp,
  scoreTone,
  threats,
  type ThreatIp,
} from "@/lib/threats";
import { cn } from "@/lib/utils";

const SCORE_STEPS = [25, 50, 75, 90, 100] as const;

function shortIsp(name: string) {
  const map: Record<string, string> = {
    CANTV: "CANTV",
    Digitel: "Digitel",
    Movistar: "Movistar",
    Movilnet: "Movilnet",
    ThunderNET: "Thunder",
    Netuno: "Netuno",
    "Fibex Telecom": "Fibex",
    "Telemic (Inter)": "Inter",
    "Gold Data": "Gold Data",
    "Datcom Services": "Datcom",
    Viginet: "Viginet",
  };
  return map[name] ?? name;
}

function scoreVariant(score: number) {
  const tone = scoreTone(score);
  if (tone === "high") return "high" as const;
  if (tone === "mid") return "mid" as const;
  return "low" as const;
}

async function copyText(label: string, value: string) {
  await navigator.clipboard.writeText(value);
  toast.success(label);
}

export function Dashboard() {
  const [isp, setIsp] = useState<string>("all");
  const [q, setQ] = useState("");
  const [minScore, setMinScore] = useState<(typeof SCORE_STEPS)[number]>(75);
  const [botnetOnly, setBotnetOnly] = useState(true);
  const [selected, setSelected] = useState<ThreatIp | null>(null);
  const [lookup, setLookup] = useState("");
  const [looking, setLooking] = useState(false);

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return threats.ips.filter((row) => {
      if (isp !== "all" && row.isp !== isp) return false;
      if (row.abuseConfidenceScore < minScore) return false;
      if (botnetOnly) {
        const hasCats = row.categories.length > 0;
        if (hasCats && !row.categories.some((c) => BOTNET_CATEGORY_IDS.has(c.id))) {
          return false;
        }
      }
      if (!needle) return true;
      return (
        row.ip.includes(needle) ||
        row.isp.toLowerCase().includes(needle) ||
        row.org.toLowerCase().includes(needle) ||
        String(row.asn).includes(needle) ||
        (row.prefix ?? "").includes(needle)
      );
    });
  }, [isp, q, minScore, botnetOnly]);

  const byIsp = useMemo(
    () =>
      threats.isps.map((item) => ({
        id: item.id,
        name: item.name,
        kind: item.kind,
        asns: item.asns,
        count: rows.filter((r) => r.isp === item.id).length,
        all: threats.ips.filter((r) => r.isp === item.id).length,
      })),
    [rows],
  );

  const chartData = byIsp.map((item) => ({
    name: shortIsp(item.name),
    count: item.count,
  }));

  const prefixes = hottestPrefixes(rows);
  const cats = categoryTotals(rows);
  const generated = formatStamp(threats.generatedAt);

  async function onLookup(e: FormEvent) {
    e.preventDefault();
    const ip = lookup.trim();
    if (!IPV4_RE.test(ip)) {
      toast.error("Escribe una IPv4 válida");
      return;
    }
    setLooking(true);
    try {
      const result = await lookupIp({ data: { ip } });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      setSelected(result.row);
      if (!result.inWatchlist) {
        toast.message("IP fuera de las 11 ISP vigiladas");
      } else if (result.botnetLikely) {
        toast.success("Reportada con patrón de botnet");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "No se pudo consultar");
    } finally {
      setLooking(false);
    }
  }

  function exportAs(format: (typeof EXPORT_FORMATS)[number]["id"]) {
    if (!rows.length) {
      toast.error("No hay IPs con el filtro actual");
      return;
    }
    const spec = EXPORT_FORMATS.find((f) => f.id === format)!;
    downloadText(`reja-ve-botnet.${spec.ext}`, buildBlocklist(rows, format));
    toast.success(`Exportadas ${rows.length} IPs`);
  }

  return (
    <main className="min-h-screen bg-background pb-16">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 sm:px-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="max-w-xl">
              <p className="text-xs font-medium tracking-[0.18em] text-muted-foreground uppercase">
                AbuseIPDB · Venezuela
              </p>
              <h1 className="mt-2 font-sans text-3xl font-medium tracking-tight text-foreground sm:text-4xl">
                Reja VE
              </h1>
              <p className="mt-2 text-sm text-muted-foreground">
                IPs maliciosas y botnet reportadas en las 11 ISP que pediste. Lista lista
                para bloquear.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                onClick={() => copyText("IPs copiadas", rows.map((r) => r.ip).join("\n"))}
              >
                <Copy />
                Copiar IPs
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button>
                    <Download />
                    Exportar bloqueo
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {EXPORT_FORMATS.map((fmt) => (
                    <DropdownMenuItem key={fmt.id} onSelect={() => exportAs(fmt.id)}>
                      {fmt.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          <form onSubmit={onLookup} className="flex flex-col gap-2 sm:flex-row">
            <Input
              value={lookup}
              onChange={(e) => setLookup(e.target.value)}
              placeholder="Consultar una IP en AbuseIPDB"
              inputMode="decimal"
              autoComplete="off"
              aria-label="Dirección IP"
              className="font-mono sm:max-w-sm"
            />
            <Button type="submit" variant="secondary" disabled={looking}>
              <Search />
              {looking ? "Consultando…" : "Verificar"}
            </Button>
          </form>
        </div>
      </header>

      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 sm:px-6">
        <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Kpi label="IPs visibles" value={formatReports(rows.length)} />
          <Kpi label="Alta confianza" value={formatReports(rows.filter((r) => r.tier === "alta").length)} />
          <Kpi
            label="Reportes (top)"
            value={formatReports(rows[0]?.totalReports ?? 0)}
            hint={rows[0]?.ip}
          />
          <Kpi label="Snapshot" value={generated} small />
        </section>

        <section className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-sm font-medium text-foreground">ISP vigiladas</h2>
            <p className="text-xs text-muted-foreground">Toque para filtrar</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <FilterChip active={isp === "all"} onClick={() => setIsp("all")} count={rows.length}>
              Todas
            </FilterChip>
            {byIsp.map((item) => (
              <FilterChip
                key={item.id}
                active={isp === item.id}
                onClick={() => setIsp(item.id === isp ? "all" : item.id)}
                count={item.count}
              >
                {item.name}
              </FilterChip>
            ))}
          </div>
        </section>

        <section className="flex flex-col gap-3 rounded-xl bg-card p-4 sm:p-5">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="relative w-full lg:max-w-sm">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar IP, ASN o prefijo"
                className="pl-10"
                aria-label="Buscar"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-muted-foreground">Confianza mín.</span>
              {SCORE_STEPS.map((step) => (
                <button
                  key={step}
                  type="button"
                  onClick={() => setMinScore(step)}
                  className={cn(
                    "h-11 min-w-11 rounded-sm px-3 font-mono text-sm transition-[background-color,color] duration-150",
                    minScore === step
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-muted-foreground hover:text-foreground",
                  )}
                >
                  {step}
                </button>
              ))}
              <Button
                type="button"
                variant={botnetOnly ? "default" : "outline"}
                onClick={() => setBotnetOnly((v) => !v)}
              >
                {botnetOnly ? <ShieldOff /> : <ShieldAlert />}
                Solo botnet
              </Button>
            </div>
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-5">
          <div className="rounded-xl bg-card p-4 lg:col-span-3 sm:p-5">
            <h2 className="text-sm font-medium">Volumen por ISP</h2>
            <p className="mt-1 text-xs text-muted-foreground">IPs que pasan el filtro actual</p>
            <div className="mt-4 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  layout="vertical"
                  margin={{ top: 4, right: 12, left: 8, bottom: 0 }}
                >
                  <XAxis
                    type="number"
                    allowDecimals={false}
                    tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={78}
                    tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <RechartsTooltip
                    cursor={{ fill: "var(--color-accent)" }}
                    contentStyle={{
                      background: "var(--color-popover)",
                      border: "1px solid var(--color-border)",
                      borderRadius: 8,
                      color: "var(--color-foreground)",
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="count" fill="var(--color-primary)" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="rounded-xl bg-card p-4 lg:col-span-2 sm:p-5">
            <h2 className="text-sm font-medium">Prefijos calientes</h2>
            <p className="mt-1 text-xs text-muted-foreground">/24 o bloques con más IPs reportadas</p>
            <ul className="mt-4 flex flex-col gap-2">
              {prefixes.length === 0 ? (
                <li className="text-sm text-muted-foreground">Sin prefijos para este filtro.</li>
              ) : (
                prefixes.map((p) => (
                  <li
                    key={p.prefix}
                    className="flex items-center justify-between gap-3 rounded-md bg-secondary px-3 py-2"
                  >
                    <div>
                      <p className="font-mono text-sm">{p.prefix}</p>
                      <p className="text-xs text-muted-foreground">{ispLabel(p.isp)}</p>
                    </div>
                    <span className="font-mono text-sm tabular-nums">{p.count}</span>
                  </li>
                ))
              )}
            </ul>
            {cats.length > 0 ? (
              <>
                <Separator className="my-4" />
                <p className="text-xs text-muted-foreground">Categorías AbuseIPDB</p>
                <ul className="mt-2 flex flex-col gap-1.5">
                  {cats.map((c) => (
                    <li key={c.name} className="flex justify-between text-sm">
                      <span>{c.name}</span>
                      <span className="font-mono tabular-nums text-muted-foreground">
                        {formatReports(c.count)}
                      </span>
                    </li>
                  ))}
                </ul>
              </>
            ) : null}
          </div>
        </section>

        <section className="flex flex-col gap-3">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="text-sm font-medium">
              {formatReports(rows.length)} direcciones
            </h2>
            <p className="text-xs text-muted-foreground">Toque una fila para el detalle</p>
          </div>

          <div className="flex flex-col gap-2 md:hidden">
            {rows.map((row) => (
              <button
                key={row.ip}
                type="button"
                onClick={() => setSelected(row)}
                className="rounded-xl bg-card p-4 text-left transition-[background-color] duration-150 hover:bg-accent"
              >
                <div className="flex items-start justify-between gap-3">
                  <p className="font-mono text-sm">{row.ip}</p>
                  <Badge variant={scoreVariant(row.abuseConfidenceScore)}>
                    {row.abuseConfidenceScore}%
                  </Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {ispLabel(row.isp)} · {formatReports(row.totalReports)} reportes
                </p>
                <p className="mt-2 line-clamp-1 text-xs text-muted-foreground">
                  {row.categories.map((c) => c.name).slice(0, 3).join(" · ") || "Sin categoría"}
                </p>
              </button>
            ))}
          </div>

          <div className="hidden overflow-x-auto rounded-xl bg-card md:block">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="text-xs text-muted-foreground">
                <tr className="border-b border-border">
                  <th className="px-4 py-3 font-medium">IP</th>
                  <th className="px-4 py-3 font-medium">ISP</th>
                  <th className="px-4 py-3 font-medium">Score</th>
                  <th className="px-4 py-3 font-medium">Reportes</th>
                  <th className="px-4 py-3 font-medium">Actividad</th>
                  <th className="px-4 py-3 font-medium">Categorías</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr
                    key={row.ip}
                    className="cursor-pointer border-b border-border/70 transition-colors duration-150 last:border-0 hover:bg-accent"
                    onClick={() => setSelected(row)}
                  >
                    <td className="px-4 py-3 font-mono text-xs">{row.ip}</td>
                    <td className="px-4 py-3">{ispLabel(row.isp)}</td>
                    <td className="px-4 py-3">
                      <Badge variant={scoreVariant(row.abuseConfidenceScore)}>
                        {row.abuseConfidenceScore}%
                      </Badge>
                    </td>
                    <td className="px-4 py-3 font-mono tabular-nums">
                      {formatReports(row.totalReports)}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{formatStamp(row.lastReportedAt)}</td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {row.categories.map((c) => c.name).slice(0, 2).join(", ") || "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {rows.length === 0 ? (
            <p className="rounded-xl bg-card px-4 py-8 text-center text-sm text-muted-foreground">
              Ninguna IP con este filtro. Baja la confianza o desactiva “solo botnet”.
              {isp === "Movilnet"
                ? " Movilnet no tiene IPs con ~100% de confianza en los últimos 90 días."
                : null}
            </p>
          ) : null}
        </section>

        <footer className="text-xs leading-relaxed text-muted-foreground">
          Snapshot {generated}. Fuente: API de AbuseIPDB (check + check-block) cruzada
          con los ASN de CANTV, Digitel, Movistar, Movilnet, ThunderNET, Netuno, Fibex, Telemic
          (Inter), Gold Data, Datcom y Viginet. Movilnet aparece en cero a este umbral. No bloquee
          rangos enteros de ISP residenciales: use la lista de IPs.
        </footer>
      </div>

      <IpDialog row={selected} onClose={() => setSelected(null)} />
    </main>
  );
}

function Kpi({
  label,
  value,
  hint,
  small,
}: {
  label: string;
  value: string;
  hint?: string;
  small?: boolean;
}) {
  return (
    <div className="rounded-xl bg-card p-4">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p
        className={cn(
          "mt-2 font-medium tracking-tight text-foreground",
          small ? "text-sm leading-snug" : "text-2xl tabular-nums",
        )}
      >
        {value}
      </p>
      {hint ? <p className="mt-1 font-mono text-xs text-muted-foreground">{hint}</p> : null}
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  count,
  children,
}: {
  active: boolean;
  onClick: () => void;
  count: number;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex h-11 items-center gap-2 rounded-full border px-3.5 text-sm transition-[background-color,color,border-color] duration-150",
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-card text-foreground hover:bg-accent",
      )}
    >
      <span>{children}</span>
      <span className={cn("font-mono text-xs tabular-nums", active ? "opacity-80" : "text-muted-foreground")}>
        {count}
      </span>
    </button>
  );
}

function IpDialog({ row, onClose }: { row: ThreatIp | null; onClose: () => void }) {
  if (!row) return null;
  const abuseUrl = `https://www.abuseipdb.com/check/${row.ip}`;
  return (
    <Dialog open={!!row} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-mono text-lg">{row.ip}</DialogTitle>
          <DialogDescription>
            {ispLabel(row.isp)}
            {row.asn ? ` · AS${row.asn}` : ""}
            {row.usageType ? ` · ${row.usageType}` : ""}
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <Meta label="Confianza" value={`${row.abuseConfidenceScore}%`} />
          <Meta label="Reportes" value={formatReports(row.totalReports)} />
          <Meta label="Último" value={formatStamp(row.lastReportedAt)} />
          <Meta label="Prefijo" value={row.prefix ?? "—"} />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {row.categories.length ? (
            row.categories.slice(0, 8).map((c) => (
              <Badge key={c.id} variant="outline">
                {c.name} {c.count}
              </Badge>
            ))
          ) : (
            <Badge variant="outline">Sin categorías detalladas</Badge>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => copyText("IP copiada", row.ip)}>
            <Copy />
            Copiar IP
          </Button>
          <Button variant="outline" asChild>
            <a href={abuseUrl} target="_blank" rel="noreferrer">
              <ExternalLink />
              AbuseIPDB
            </a>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-secondary px-3 py-2">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-mono text-sm">{value}</p>
    </div>
  );
}

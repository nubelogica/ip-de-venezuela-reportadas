import type { ThreatIp } from "@/lib/threats";

export type ExportFormat =
  | "txt"
  | "csv"
  | "iptables"
  | "nftables"
  | "nginx"
  | "mikrotik";

export const EXPORT_FORMATS: { id: ExportFormat; label: string; ext: string }[] = [
  { id: "txt", label: "Lista de IPs", ext: "txt" },
  { id: "csv", label: "CSV", ext: "csv" },
  { id: "iptables", label: "iptables", ext: "sh" },
  { id: "nftables", label: "nftables", ext: "nft" },
  { id: "nginx", label: "Nginx deny", ext: "conf" },
  { id: "mikrotik", label: "MikroTik", ext: "rsc" },
];

function csvEscape(value: string | number | null | undefined): string {
  const s = value == null ? "" : String(value);
  if (/[",\n]/.test(s)) return `"${s.replaceAll('"', '""')}"`;
  return s;
}

export function buildBlocklist(rows: ThreatIp[], format: ExportFormat): string {
  const ips = rows.map((r) => r.ip);
  switch (format) {
    case "txt":
      return ips.join("\n") + (ips.length ? "\n" : "");
    case "csv": {
      const header = [
        "ip",
        "isp",
        "asn",
        "prefix",
        "score",
        "reports",
        "lastReportedAt",
        "categories",
        "usageType",
      ].join(",");
      const lines = rows.map((r) =>
        [
          r.ip,
          r.isp,
          r.asn,
          r.prefix ?? "",
          r.abuseConfidenceScore,
          r.totalReports ?? "",
          r.lastReportedAt ?? "",
          r.categories.map((c) => c.name).join("|"),
          r.usageType ?? "",
        ]
          .map(csvEscape)
          .join(","),
      );
      return [header, ...lines].join("\n") + "\n";
    }
    case "iptables":
      return (
        "#!/bin/sh\n# Reja VE — bloqueo botnet ISP venezolanas\niptables -N REJA_VE 2>/dev/null || true\n" +
        ips.map((ip) => `iptables -A REJA_VE -s ${ip} -j DROP`).join("\n") +
        "\niptables -C INPUT -j REJA_VE 2>/dev/null || iptables -I INPUT -j REJA_VE\n"
      );
    case "nftables":
      return (
        "#!/usr/sbin/nft -f\nadd table inet reja_ve\nadd chain inet reja_ve input { type filter hook input priority 0; }\n" +
        ips.map((ip) => `add rule inet reja_ve input ip saddr ${ip} drop`).join("\n") +
        "\n"
      );
    case "nginx":
      return ips.map((ip) => `deny ${ip};`).join("\n") + (ips.length ? "\n" : "");
    case "mikrotik":
      return (
        ips
          .map(
            (ip) =>
              `/ip firewall address-list add list=reja-ve-botnet address=${ip} comment="AbuseIPDB VE"`,
          )
          .join("\n") + (ips.length ? "\n" : "")
      );
  }
}

export function downloadText(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

import { BOTNET_CATEGORY_IDS, type CategoryHit, type ThreatIp } from "@/lib/threats";

const ABUSEIPDB_KEY =
  "365ede59ae5b9332b9fbee36172ad96b33877747ee09d4b9897d329272de6ce2d2c98049b18504f2";

const CATEGORIES: Record<number, string> = {
  1: "Compromiso DNS",
  2: "Envenenamiento DNS",
  3: "Fraude pedidos",
  4: "Ataque DDoS",
  5: "Fuerza bruta FTP",
  6: "Ping of Death",
  7: "Phishing",
  8: "Fraude VoIP",
  9: "Proxy abierto",
  10: "Web spam",
  11: "Email spam",
  12: "Blog spam",
  13: "IP VPN",
  14: "Escaneo de puertos",
  15: "Hacking",
  16: "Inyección SQL",
  17: "Spoofing",
  18: "Fuerza bruta",
  19: "Bot web malicioso",
  20: "Host explotado",
  21: "Ataque web",
  22: "SSH",
  23: "IoT dirigido",
};

const ISP_ASN: Record<number, string> = {
  8048: "CANTV",
  10293: "CANTV",
  264731: "Digitel",
  27717: "Digitel",
  6306: "Movistar",
  27889: "Movilnet",
  272809: "ThunderNET",
  11562: "Netuno",
  264628: "Fibex Telecom",
  274267: "Fibex Telecom",
  21826: "Corporacion Telemic",
  28007: "Gold Data",
  394684: "Gold Data",
  272871: "Datcom Services",
  263703: "Viginet",
};

type CheckResponse = {
  data?: {
    ipAddress: string;
    abuseConfidenceScore: number;
    countryCode?: string;
    usageType?: string | null;
    isp?: string;
    domain?: string | null;
    isWhitelisted?: boolean | null;
    isTor?: boolean;
    totalReports?: number;
    numDistinctUsers?: number;
    lastReportedAt?: string | null;
    hostnames?: string[];
    reports?: { categories?: number[] }[];
  };
  errors?: { detail?: string }[];
};

export type LookupResult = {
  ok: true;
  row: ThreatIp;
  inWatchlist: boolean;
  botnetLikely: boolean;
} | {
  ok: false;
  error: string;
};

function matchIsp(ispName: string | undefined): string | null {
  if (!ispName) return null;
  const n = ispName.toUpperCase();
  if (n.includes("CANTV")) return "CANTV";
  if (n.includes("DIGITEL")) return "Digitel";
  if (n.includes("TELEFONICA") || n.includes("MOVISTAR")) return "Movistar";
  if (n.includes("MOVILNET")) return "Movilnet";
  if (n.includes("THUNDERNET")) return "ThunderNET";
  if (n.includes("NET UNO") || n.includes("NETUNO")) return "Netuno";
  if (n.includes("FIBEX")) return "Fibex Telecom";
  if (n.includes("TELEMIC")) return "Corporacion Telemic";
  if (n.includes("GOLD DATA")) return "Gold Data";
  if (n.includes("DAT-COM") || n.includes("DATCOM")) return "Datcom Services";
  if (n.includes("VIGINET")) return "Viginet";
  return null;
}

export async function checkIp(ip: string): Promise<LookupResult> {
  const url = new URL("https://api.abuseipdb.com/api/v2/check");
  url.searchParams.set("ipAddress", ip);
  url.searchParams.set("maxAgeInDays", "30");
  url.searchParams.set("verbose", "");

  const res = await fetch(url, {
    headers: {
      Key: ABUSEIPDB_KEY,
      Accept: "application/json",
    },
  });

  const body = (await res.json()) as CheckResponse;
  if (!res.ok || body.errors?.length) {
    return {
      ok: false,
      error: body.errors?.[0]?.detail ?? `AbuseIPDB respondió ${res.status}`,
    };
  }
  const data = body.data;
  if (!data) return { ok: false, error: "Respuesta vacía de AbuseIPDB" };

  const catCounts = new Map<number, number>();
  for (const report of data.reports ?? []) {
    for (const id of report.categories ?? []) {
      catCounts.set(id, (catCounts.get(id) ?? 0) + 1);
    }
  }
  const categories: CategoryHit[] = [...catCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([id, count]) => ({ id, name: CATEGORIES[id] ?? String(id), count }));

  const isp = matchIsp(data.isp) ?? "Otra";
  const score = data.abuseConfidenceScore ?? 0;
  const row: ThreatIp = {
    ip: data.ipAddress,
    isp,
    asn: 0,
    org: data.isp ?? "Desconocido",
    prefix: null,
    countryCode: data.countryCode ?? "",
    usageType: data.usageType ?? null,
    ispName: data.isp ?? "Desconocido",
    domain: data.domain ?? null,
    isWhitelisted: Boolean(data.isWhitelisted),
    isTor: Boolean(data.isTor),
    abuseConfidenceScore: score,
    totalReports: data.totalReports ?? 0,
    numDistinctUsers: data.numDistinctUsers ?? null,
    lastReportedAt: data.lastReportedAt ?? null,
    categories,
    hostnames: data.hostnames ?? [],
    tier: score >= 75 ? "alta" : "reportada",
    windowDays: 30,
    source: "abuseipdb-check-live",
    checkOk: true,
  };

  return {
    ok: true,
    row,
    inWatchlist: isp !== "Otra",
    botnetLikely: categories.some((c) => BOTNET_CATEGORY_IDS.has(c.id)),
  };
}

export { ISP_ASN };

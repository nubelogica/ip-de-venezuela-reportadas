import dataset from "@/data/threats.json";

export type CategoryHit = {
  id: number;
  name: string;
  count: number;
};

export type ThreatIp = {
  ip: string;
  isp: string;
  asn: number;
  org: string;
  prefix: string | null;
  countryCode: string;
  usageType: string | null;
  ispName: string;
  domain: string | null;
  isWhitelisted: boolean;
  isTor: boolean;
  abuseConfidenceScore: number;
  totalReports: number | null;
  numDistinctUsers: number | null;
  lastReportedAt: string | null;
  categories: CategoryHit[];
  hostnames: string[];
  tier: "alta" | "reportada";
  windowDays: number;
  source: string;
  checkOk: boolean;
};

export type IspMeta = {
  id: string;
  name: string;
  asns: number[];
  kind: string;
};

export type ThreatDataset = {
  generatedAt: string;
  windowDays: number;
  sources: string[];
  isps: IspMeta[];
  stats: {
    total: number;
    alta: number;
    reportada: number;
    byIsp: Record<string, number>;
    failedChecks: number;
  };
  ips: ThreatIp[];
};

export const BOTNET_CATEGORY_IDS = new Set([4, 5, 14, 15, 18, 19, 20, 21, 22, 23]);

export const threats = dataset as ThreatDataset;

export function ispLabel(id: string): string {
  return threats.isps.find((isp) => isp.id === id)?.name ?? id;
}

export function formatReports(n: number | null): string {
  if (n == null) return "—";
  return new Intl.NumberFormat("es-VE").format(n);
}

export function formatStamp(iso: string | null): string {
  if (!iso) return "sin fecha";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "sin fecha";
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  const h = String(d.getUTCHours()).padStart(2, "0");
  const min = String(d.getUTCMinutes()).padStart(2, "0");
  return `${day}/${m}/${y} ${h}:${min} UTC`;
}

export function scoreTone(score: number): "high" | "mid" | "low" {
  if (score >= 90) return "high";
  if (score >= 50) return "mid";
  return "low";
}

export function hottestPrefixes(rows: ThreatIp[], limit = 6) {
  const map = new Map<string, { prefix: string; isp: string; count: number; maxScore: number }>();
  for (const row of rows) {
    if (!row.prefix) continue;
    const cur = map.get(row.prefix) ?? {
      prefix: row.prefix,
      isp: row.isp,
      count: 0,
      maxScore: 0,
    };
    cur.count += 1;
    cur.maxScore = Math.max(cur.maxScore, row.abuseConfidenceScore);
    map.set(row.prefix, cur);
  }
  return [...map.values()].sort((a, b) => b.count - a.count || b.maxScore - a.maxScore).slice(0, limit);
}

export function categoryTotals(rows: ThreatIp[], limit = 6) {
  const counts = new Map<string, number>();
  for (const row of rows) {
    for (const cat of row.categories) {
      counts.set(cat.name, (counts.get(cat.name) ?? 0) + cat.count);
    }
  }
  return [...counts.entries()]
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

export const IPV4_RE =
  /^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;

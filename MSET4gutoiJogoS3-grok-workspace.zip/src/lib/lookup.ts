import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  ip: z
    .string()
    .trim()
    .regex(/^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/, "IP IPv4 inválida"),
});

export const lookupIp = createServerFn({ method: "POST" })
  .validator(Input)
  .handler(async ({ data }) => {
    const { checkIp } = await import("./abuseipdb.server.ts");
    return checkIp(data.ip);
  });

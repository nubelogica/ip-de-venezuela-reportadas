//#region node_modules/.nitro/vite/services/ssr/assets/threats-9uujkDr2.js
var threats_default = {
	generatedAt: "2026-10-04T06:15:11Z",
	windowDays: 30,
	sources: [
		"AbuseIPDB APIv2 check (maxAge 30d, verbose)",
		"AbuseIPDB APIv2 check-block (Datcom /24)",
		"AbuseIPDB aggregated s100 30/90d (borestad, con permiso de AbuseIPDB)"
	],
	isps: [
		{
			"id": "CANTV",
			"name": "CANTV",
			"asns": [8048, 10293],
			"kind": "fijo / estatal"
		},
		{
			"id": "Digitel",
			"name": "Digitel",
			"asns": [264731, 27717],
			"kind": "móvil"
		},
		{
			"id": "Movistar",
			"name": "Movistar",
			"asns": [6306],
			"kind": "móvil"
		},
		{
			"id": "Movilnet",
			"name": "Movilnet",
			"asns": [27889],
			"kind": "móvil"
		},
		{
			"id": "ThunderNET",
			"name": "ThunderNET",
			"asns": [272809],
			"kind": "fibra"
		},
		{
			"id": "Netuno",
			"name": "Netuno",
			"asns": [11562],
			"kind": "fibra"
		},
		{
			"id": "Fibex Telecom",
			"name": "Fibex Telecom",
			"asns": [264628, 274267],
			"kind": "fibra"
		},
		{
			"id": "Corporacion Telemic",
			"name": "Telemic (Inter)",
			"asns": [21826],
			"kind": "fibra"
		},
		{
			"id": "Gold Data",
			"name": "Gold Data",
			"asns": [28007, 394684],
			"kind": "carrier / DC"
		},
		{
			"id": "Datcom Services",
			"name": "Datcom Services",
			"asns": [272871],
			"kind": "hosting"
		},
		{
			"id": "Viginet",
			"name": "Viginet",
			"asns": [263703],
			"kind": "fibra"
		}
	],
	stats: {
		"total": 373,
		"alta": 322,
		"reportada": 51,
		"byIsp": {
			"CANTV": 58,
			"Netuno": 16,
			"Corporacion Telemic": 30,
			"Movistar": 6,
			"Fibex Telecom": 84,
			"Gold Data": 13,
			"ThunderNET": 19,
			"Viginet": 85,
			"Digitel": 9,
			"Datcom Services": 53
		},
		"failedChecks": 0
	},
	ips: [
		{
			"ip": "190.202.87.179",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.87.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 2769,
			"numDistinctUsers": 668,
			"lastReportedAt": "2026-10-04T00:57:48+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 93
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 93
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 12
				},
				{
					"id": 6,
					"name": "Ping of Death",
					"count": 12
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 12
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 12
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 12
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": ["190-202-87-179-cnt-02.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.71.251",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 2464,
			"numDistinctUsers": 697,
			"lastReportedAt": "2026-10-03T15:06:14+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 83
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 79
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 11
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				}
			],
			"hostnames": ["correo.mindeporte.gob.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.5.52",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.0.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 2292,
			"numDistinctUsers": 520,
			"lastReportedAt": "2026-10-04T06:13:20+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 78
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 76
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 20
				}
			],
			"hostnames": ["correo.cenaoz.gob.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.192.30",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.192.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 2254,
			"numDistinctUsers": 828,
			"lastReportedAt": "2026-10-04T06:09:18+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 96
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 95
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["201-249-192-30.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.6.32.107",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.6.32.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 1555,
			"numDistinctUsers": 646,
			"lastReportedAt": "2026-10-03T23:06:10+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 94
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 92
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				}
			],
			"hostnames": ["host-190-6-32-107.NET-UNO.NET"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.89.69",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.88.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 1444,
			"numDistinctUsers": 236,
			"lastReportedAt": "2026-09-30T14:40:05+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 92
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 91
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": ["mail.sunad.gob.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.88.51",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.88.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 1419,
			"numDistinctUsers": 561,
			"lastReportedAt": "2026-09-29T20:55:51+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 95
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 89
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": ["correo.minaguas.gob.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.132.74",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.132.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 1130,
			"numDistinctUsers": 302,
			"lastReportedAt": "2026-09-30T16:01:06+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 100
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 99
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": ["mail.nuctechve.com"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.142.97.50",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "190.142.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 916,
			"numDistinctUsers": 173,
			"lastReportedAt": "2026-09-29T03:20:12+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 91
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 88
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 6,
					"name": "Ping of Death",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.103.198",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.103.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 467,
			"numDistinctUsers": 213,
			"lastReportedAt": "2026-09-30T16:01:07+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 86
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 80
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				}
			],
			"hostnames": ["198.103.153.190.net-uno.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.103.238",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.103.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 432,
			"numDistinctUsers": 251,
			"lastReportedAt": "2026-09-27T07:04:19+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 93
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 90
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["238.103.153.190.net-uno.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.89.102",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.80.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 384,
			"numDistinctUsers": 199,
			"lastReportedAt": "2026-10-01T03:11:25+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 87
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 87
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 9
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["201-249-89-102-bto-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.21.124",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.21.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 321,
			"numDistinctUsers": 86,
			"lastReportedAt": "2026-10-04T03:10:10+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 92
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 17
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 12
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				}
			],
			"hostnames": ["correo.password.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.83.181",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.83.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 265,
			"numDistinctUsers": 122,
			"lastReportedAt": "2026-10-02T11:08:23+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 94
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 84
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["190-202-83-181-cnt-02.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.205.58.18",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.205.56.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 242,
			"numDistinctUsers": 127,
			"lastReportedAt": "2026-09-18T03:38:16+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 86
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 20
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 18
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": ["190-205-58-18.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.73.26.46",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.73.0.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 238,
			"numDistinctUsers": 111,
			"lastReportedAt": "2026-10-04T03:01:59+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 86
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 20
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 11
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["190-73-26-46-chc-00-p69.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.228.57",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 225,
			"numDistinctUsers": 162,
			"lastReportedAt": "2026-10-01T12:40:16+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 91
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 90
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.205.59.62",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.205.56.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 172,
			"numDistinctUsers": 40,
			"lastReportedAt": "2026-10-04T00:14:04+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 66
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 35
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 15
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["190-205-59-62.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.35.109.130",
			"isp": "Movistar",
			"asn": 6306,
			"org": "TELEFONICA VENEZOLANA, C.A.",
			"prefix": "200.35.108.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "TELEFONICA VENEZOLANA, C.A.",
			"domain": "telefonica.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 145,
			"numDistinctUsers": 44,
			"lastReportedAt": "2026-10-03T03:00:09+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 61
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 42
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 9
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				}
			],
			"hostnames": ["200-35-109-130.static.telcel.net.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.49.236",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.48.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 131,
			"numDistinctUsers": 88,
			"lastReportedAt": "2026-10-02T00:10:02+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 86
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 83
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				}
			],
			"hostnames": ["correo.mindeporte.gob.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.75.133.2",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "200.75.133.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 115,
			"numDistinctUsers": 66,
			"lastReportedAt": "2026-10-03T18:53:33+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 93
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 91
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": ["mail.inproceca.com"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.248.67.246",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.248.64.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 113,
			"numDistinctUsers": 33,
			"lastReportedAt": "2026-10-04T01:02:58+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 72
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 41
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": ["201-248-67-246.cnt-02.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.205.94",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.192.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 111,
			"numDistinctUsers": 45,
			"lastReportedAt": "2026-10-04T05:25:03+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 88
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 66
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				}
			],
			"hostnames": ["201-249-201-94.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.30.16",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.30.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 109,
			"numDistinctUsers": 67,
			"lastReportedAt": "2026-10-03T18:30:23+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 58
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 41
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 38
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 19
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 17
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 12
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.109",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 104,
			"numDistinctUsers": 45,
			"lastReportedAt": "2026-10-04T03:03:03+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 42
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 38
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 15
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 15
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 15
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 14
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 6
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 2
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.208.172.85",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.208.160.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 98,
			"numDistinctUsers": 58,
			"lastReportedAt": "2026-09-16T12:00:18+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 81
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 23
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 11
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 9
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				}
			],
			"hostnames": ["201-208-172-85-chc-00-p65.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "131.108.6.190",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "131.108.4.0/22",
			"countryCode": "PA",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data Panama Corp",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 95,
			"numDistinctUsers": 52,
			"lastReportedAt": "2026-10-04T05:38:35+00:00",
			"categories": [
				{
					"id": 21,
					"name": "Ataque web",
					"count": 64
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 53
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 15
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 15
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 5
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.209.112.83",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.209.96.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 94,
			"numDistinctUsers": 55,
			"lastReportedAt": "2026-09-18T00:00:31+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 84
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 12
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["201-209-112-83-chc-00-p64.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.109.233.2",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "200.109.232.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 81,
			"numDistinctUsers": 36,
			"lastReportedAt": "2026-10-03T16:44:57+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 54
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 26
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 11
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["200.109.233-2.cnt-02.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "82.86.65.174",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "82.86.64.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Telecom Castilla La Mancha SA",
			"domain": "telecomclm.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 79,
			"numDistinctUsers": 51,
			"lastReportedAt": "2026-10-03T22:00:30+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 66
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 23
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 15
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 7
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.29.11",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 71,
			"numDistinctUsers": 51,
			"lastReportedAt": "2026-10-04T03:10:12+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 49
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 29
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 24
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.230.138",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.230.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 68,
			"numDistinctUsers": 35,
			"lastReportedAt": "2026-10-02T17:50:28+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 32
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 22
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 21
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 20
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 19
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 13,
					"name": "IP VPN",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.171",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 67,
			"numDistinctUsers": 41,
			"lastReportedAt": "2026-10-04T06:09:37+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 45
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 22
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 17
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 17
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 8
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.31.25",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 65,
			"numDistinctUsers": 32,
			"lastReportedAt": "2026-10-02T12:00:32+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 29
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 20
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 19
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 14
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 12
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.251.237",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.251.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 65,
			"numDistinctUsers": 36,
			"lastReportedAt": "2026-10-04T03:39:01+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 33
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 29
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 23
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.54.130",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 65,
			"numDistinctUsers": 41,
			"lastReportedAt": "2026-10-04T00:08:39+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 51
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 22
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 19
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 13
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.48.235",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Alivensa Poruguesa",
			"domain": "guardian.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 64,
			"numDistinctUsers": 30,
			"lastReportedAt": "2026-10-04T02:06:15+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 46
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 23
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 14
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.29.10",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 64,
			"numDistinctUsers": 45,
			"lastReportedAt": "2026-10-03T14:04:04+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 43
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 20
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 20
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 11
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.196",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 64,
			"numDistinctUsers": 44,
			"lastReportedAt": "2026-10-04T05:50:31+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 34
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 27
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 27
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 9
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.8.165.207",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.8.165.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 61,
			"numDistinctUsers": 34,
			"lastReportedAt": "2026-10-03T11:50:26+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 34
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 16
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 12
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 12
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 11
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.29.176",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 60,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-04T03:56:49+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 28
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 17
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 13
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.174.84",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.172.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 60,
			"numDistinctUsers": 31,
			"lastReportedAt": "2026-10-03T03:10:08+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 52
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 18
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 11
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 10
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.79",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 60,
			"numDistinctUsers": 27,
			"lastReportedAt": "2026-09-30T07:04:35+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 26
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 23
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 19
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 11
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.30.127",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.30.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 58,
			"numDistinctUsers": 41,
			"lastReportedAt": "2026-10-03T04:42:29+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 34
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 26
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 25
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 11
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.235.250",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 58,
			"numDistinctUsers": 39,
			"lastReportedAt": "2026-10-01T00:10:06+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 35
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 17
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 11
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.54.150",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 58,
			"numDistinctUsers": 44,
			"lastReportedAt": "2026-10-04T03:28:02+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 41
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 20
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 17
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 9
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 13,
					"name": "IP VPN",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.31.157",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 55,
			"numDistinctUsers": 37,
			"lastReportedAt": "2026-10-03T13:30:34+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 31
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 18
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 18
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 9
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 12,
					"name": "Blog spam",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.35.87.162",
			"isp": "Movistar",
			"asn": 6306,
			"org": "TELEFONICA VENEZOLANA, C.A.",
			"prefix": "200.35.84.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "SIVENSA (Division de SIDETUR)",
			"domain": "siven.it",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 54,
			"numDistinctUsers": 29,
			"lastReportedAt": "2026-10-03T19:05:08+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 41
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 17
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["200-35-87-162.static.telcel.net.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.112.163",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CIDATA ARAURE",
			"domain": "digitel.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 53,
			"numDistinctUsers": 31,
			"lastReportedAt": "2026-10-01T11:30:04+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 38
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 17
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 16
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.54",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 53,
			"numDistinctUsers": 28,
			"lastReportedAt": "2026-10-03T06:11:28+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 27
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 21
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 19
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.82.255.35",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.82.128.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 51,
			"numDistinctUsers": 33,
			"lastReportedAt": "2026-10-02T09:30:27+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 40
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 14
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 11
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 11
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 13,
					"name": "IP VPN",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.248.70.122",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.248.64.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 51,
			"numDistinctUsers": 21,
			"lastReportedAt": "2026-10-04T03:05:49+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 43
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 17
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				}
			],
			"hostnames": ["201-248-69-122.cnt-02.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.31.131",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 50,
			"numDistinctUsers": 37,
			"lastReportedAt": "2026-10-03T04:00:41+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 32
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 20
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 19
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 7
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 1
				},
				{
					"id": 6,
					"name": "Ping of Death",
					"count": 1
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.112.203",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "MINET, C.A - LARA",
			"domain": "digitel.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 49,
			"numDistinctUsers": 30,
			"lastReportedAt": "2026-10-04T06:00:31+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 30
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 19
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 17
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 11
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.31.161",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 49,
			"numDistinctUsers": 32,
			"lastReportedAt": "2026-10-01T01:01:34+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 28
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 19
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 17
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.7.78",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.0.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 49,
			"numDistinctUsers": 27,
			"lastReportedAt": "2026-10-03T04:06:05+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 39
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 16
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["mail.fontur.gob.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.30.116",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.30.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 49,
			"numDistinctUsers": 31,
			"lastReportedAt": "2026-10-04T04:24:31+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 37
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 22
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 12
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 12
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.205.106.42",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.205.96.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 48,
			"numDistinctUsers": 24,
			"lastReportedAt": "2026-10-03T10:05:17+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 43
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": ["190-205-106-42.bol-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.205.60.70",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.205.56.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 47,
			"numDistinctUsers": 25,
			"lastReportedAt": "2026-10-03T19:05:08+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 38
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["190-205-60-70.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.6.196",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.6.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 46,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-02T08:00:21+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 40
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 8
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 9,
					"name": "Proxy abierto",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": ["host-190-153-6-196.NET-UNO.NET"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.96.74.66",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "186.96.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data C.A.",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 45,
			"numDistinctUsers": 24,
			"lastReportedAt": "2026-10-04T03:10:12+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 33
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 14
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.31.132",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 45,
			"numDistinctUsers": 33,
			"lastReportedAt": "2026-10-04T01:45:27+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 31
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 11
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "82.86.78.22",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "82.86.76.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Telecom Castilla La Mancha SA",
			"domain": "telecomclm.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 45,
			"numDistinctUsers": 33,
			"lastReportedAt": "2026-10-03T21:55:22+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 33
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 16
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 14
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 12
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.28.162",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.28.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 44,
			"numDistinctUsers": 28,
			"lastReportedAt": "2026-10-03T18:30:24+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 32
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 17
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 16
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.75.152.101",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.75.128.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 44,
			"numDistinctUsers": 25,
			"lastReportedAt": "2026-10-03T17:55:19+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 31
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 21
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["190.75-152-101.pod-00-p67.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.8.164.56",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.8.164.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 44,
			"numDistinctUsers": 20,
			"lastReportedAt": "2026-10-03T19:05:08+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 36
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 14
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.235.243",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 44,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-03T23:04:09+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 28
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 11
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 13,
					"name": "IP VPN",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.28.160",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.28.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 43,
			"numDistinctUsers": 30,
			"lastReportedAt": "2026-10-03T00:17:11+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 30
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 16
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 14
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.51.114",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.48.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 43,
			"numDistinctUsers": 25,
			"lastReportedAt": "2026-10-03T06:30:31+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 26
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 24
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 20
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 13,
					"name": "IP VPN",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["190-202-51-114.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.85.35",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.85.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 43,
			"numDistinctUsers": 24,
			"lastReportedAt": "2026-10-02T20:49:22+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 35
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 12
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 3
				}
			],
			"hostnames": ["190-202-85-35-cnt-02.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.30.102",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.30.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 43,
			"numDistinctUsers": 34,
			"lastReportedAt": "2026-10-03T03:08:04+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 30
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 14
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 8
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.174",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 41,
			"numDistinctUsers": 30,
			"lastReportedAt": "2026-10-03T01:15:05+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 22
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 12
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 10
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 5
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 2
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 12,
					"name": "Blog spam",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.30.78",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.30.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 38,
			"numDistinctUsers": 23,
			"lastReportedAt": "2026-10-03T06:30:31+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 20
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 10
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 9
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.30.17",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.30.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 38,
			"numDistinctUsers": 25,
			"lastReportedAt": "2026-10-03T00:52:36+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 22
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 12
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 11
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.166.171",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.166.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 38,
			"numDistinctUsers": 27,
			"lastReportedAt": "2026-10-04T00:05:57+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 28
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 27
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				}
			],
			"hostnames": ["201-249-166-171.bol-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.71.154.140",
			"isp": "Movistar",
			"asn": 6306,
			"org": "TELEFONICA VENEZOLANA, C.A.",
			"prefix": "200.71.144.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "TELEFONICA VENEZOLANA, C.A.",
			"domain": "telefonica.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 37,
			"numDistinctUsers": 23,
			"lastReportedAt": "2026-10-03T06:06:32+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 27
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 16
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["200-71-154-140.static.telcel.net.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.169.18",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.168.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 37,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-03T09:30:33+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 35
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 12
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.84",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 37,
			"numDistinctUsers": 29,
			"lastReportedAt": "2026-10-02T11:42:07+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 21
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 6
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 1
				},
				{
					"id": 6,
					"name": "Ping of Death",
					"count": 1
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.29.8",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 36,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-02T06:08:24+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 26
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 10
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 10
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.6.11.117",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.6.11.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 36,
			"numDistinctUsers": 29,
			"lastReportedAt": "2026-10-03T09:31:42+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 29
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 8
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				}
			],
			"hostnames": ["host-190-6-11-117.NET-UNO.NET"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.53",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 36,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-04T02:46:57+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 18
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 12
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 11
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.9.44",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 36,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-02T06:44:01+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 26
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.52",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 35,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-01T02:04:10+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 19
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.244.79",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.244.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 35,
			"numDistinctUsers": 25,
			"lastReportedAt": "2026-10-03T08:58:22+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 28
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 12
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.130",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 33,
			"numDistinctUsers": 23,
			"lastReportedAt": "2026-09-29T16:27:28+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 15
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 8
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "167.249.32.178",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "167.249.32.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 32,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-03T04:34:05+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 15
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 10
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 10
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.96.67.20",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "186.96.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data C.A.",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 32,
			"numDistinctUsers": 24,
			"lastReportedAt": "2026-10-04T00:58:17+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 13
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 12
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.31.60",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 31,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-01T12:33:29+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 18
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 16
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 14
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.69.50",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 30,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-03T13:14:42+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 12
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 10
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["201-249-69-50-bto-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.90.8.86",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "200.90.8.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 27,
			"numDistinctUsers": 19,
			"lastReportedAt": "2026-09-23T01:41:37+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 24
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 20
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				}
			],
			"hostnames": ["200-90-8-86.bol-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.90.8.90",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "200.90.8.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 26,
			"numDistinctUsers": 20,
			"lastReportedAt": "2026-09-27T07:06:09+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 21
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 21
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				}
			],
			"hostnames": ["200-90-8-90.bol-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.87.203",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.80.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 26,
			"numDistinctUsers": 16,
			"lastReportedAt": "2026-09-27T07:06:14+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 20
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 20
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				}
			],
			"hostnames": ["201.249.87-203.bto-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "143.255.87.177",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "143.255.87.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 25,
			"numDistinctUsers": 19,
			"lastReportedAt": "2026-10-01T18:30:03+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 11
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["ip-143-255-87-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "82.86.128.99",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "82.86.128.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Telecom Castilla La Mancha SA",
			"domain": "telecomclm.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 25,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-09-30T20:42:42+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 17
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 9
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.123",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 23,
			"numDistinctUsers": 20,
			"lastReportedAt": "2026-10-04T05:36:22+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 12
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 8
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.87.201",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.80.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 23,
			"numDistinctUsers": 14,
			"lastReportedAt": "2026-09-27T07:06:14+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 19
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 19
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				}
			],
			"hostnames": ["201.249.87-201.bto-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.97",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 21,
			"numDistinctUsers": 10,
			"lastReportedAt": "2026-09-29T15:36:11+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 12
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.75.248.87",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.75.224.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 4,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-09-06T00:04:51+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": ["190-75-248-87-chc-00-p66.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.125.188.214",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "200.125.184.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data C.A.",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 3,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-20T16:03:26+00:00",
			"categories": [{
				"id": 18,
				"name": "Fuerza bruta",
				"count": 3
			}, {
				"id": 22,
				"name": "SSH",
				"count": 3
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.208.182.123",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.208.160.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 100,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-13T22:06:35+00:00",
			"categories": [{
				"id": 18,
				"name": "Fuerza bruta",
				"count": 1
			}],
			"hostnames": ["201-208-182-123-chc-00-p65.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.38.234",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.32.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 99,
			"totalReports": 47,
			"numDistinctUsers": 19,
			"lastReportedAt": "2026-10-04T00:02:40+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 42
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": ["190-202-38-234-chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.248.180",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.248.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 99,
			"totalReports": 42,
			"numDistinctUsers": 21,
			"lastReportedAt": "2026-10-04T04:17:10+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 24
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 20
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 19
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.13.114",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.0.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 99,
			"totalReports": 26,
			"numDistinctUsers": 20,
			"lastReportedAt": "2026-10-03T01:22:19+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 19
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": ["190-202-13-114.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.122.208",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 99,
			"totalReports": 23,
			"numDistinctUsers": 17,
			"lastReportedAt": "2026-10-04T02:57:05+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.66.10",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "SUPER OCTANOS",
			"domain": "superoctanos.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 98,
			"totalReports": 49,
			"numDistinctUsers": 20,
			"lastReportedAt": "2026-10-03T13:05:08+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 40
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 9
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.28.172",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.28.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 98,
			"totalReports": 41,
			"numDistinctUsers": 27,
			"lastReportedAt": "2026-10-02T00:31:10+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 17
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 14
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 10
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 10
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.112.214",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "MEGA SYS ARAGUA SEDE SABANETA",
			"domain": "digitel.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 98,
			"totalReports": 30,
			"numDistinctUsers": 21,
			"lastReportedAt": "2026-10-03T12:09:50+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 14
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 13
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 1
				},
				{
					"id": 6,
					"name": "Ping of Death",
					"count": 1
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.55",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 97,
			"totalReports": 41,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-09-30T02:30:02+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 18
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 14
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 13
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.210.152",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.210.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 97,
			"totalReports": 35,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-01T00:24:24+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 25
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 14
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 13
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 7,
					"name": "Phishing",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["ip-45-186-210-152.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.30.67",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.30.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 96,
			"totalReports": 28,
			"numDistinctUsers": 21,
			"lastReportedAt": "2026-10-04T02:21:29+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 14
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.9.88",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 95,
			"totalReports": 36,
			"numDistinctUsers": 23,
			"lastReportedAt": "2026-10-04T00:57:34+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 28
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 6
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.16.86",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.16.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 95,
			"totalReports": 31,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-04T00:02:12+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 23
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 21
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				}
			],
			"hostnames": ["86.16.153.190.net-uno.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.9.126",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 95,
			"totalReports": 31,
			"numDistinctUsers": 20,
			"lastReportedAt": "2026-10-03T13:30:01+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 16
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 11
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 11
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.235.120",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.235.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 95,
			"totalReports": 25,
			"numDistinctUsers": 18,
			"lastReportedAt": "2026-10-01T00:28:37+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 18
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 12
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 10
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.29.63",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 94,
			"totalReports": 39,
			"numDistinctUsers": 20,
			"lastReportedAt": "2026-10-04T04:28:50+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 21
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 12
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 11
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.35.94.45",
			"isp": "Movistar",
			"asn": 6306,
			"org": "TELEFONICA VENEZOLANA, C.A.",
			"prefix": "200.35.92.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Servicio Panamericano De Proteccin, C.A.",
			"domain": "telefonica.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 93,
			"totalReports": 52,
			"numDistinctUsers": 17,
			"lastReportedAt": "2026-10-03T09:03:12+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 33
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 18
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				}
			],
			"hostnames": ["200-35-94-45.static.telcel.net.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.169",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 93,
			"totalReports": 40,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-01T00:25:26+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 28
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.205.59.6",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.205.56.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 93,
			"totalReports": 33,
			"numDistinctUsers": 21,
			"lastReportedAt": "2026-10-01T22:04:52+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 21
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 15
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["190-205-59-6.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.31.135",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 93,
			"totalReports": 31,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-10-02T01:12:16+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 20
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 12
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 11
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.250.55",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.250.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 92,
			"totalReports": 27,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-09-25T17:18:53+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 24
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "143.255.85.99",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "143.255.85.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 92,
			"totalReports": 26,
			"numDistinctUsers": 18,
			"lastReportedAt": "2026-10-04T04:13:37+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 19
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["ip-143-255-85-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.114",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 91,
			"totalReports": 41,
			"numDistinctUsers": 28,
			"lastReportedAt": "2026-10-02T18:32:58+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 25
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.202.18.190",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.202.16.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 91,
			"totalReports": 40,
			"numDistinctUsers": 18,
			"lastReportedAt": "2026-10-04T05:58:55+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 34
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 9
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["190-202-18-190.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "170.246.77.74",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "170.246.77.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 91,
			"totalReports": 7,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-27T07:00:17+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				}
			],
			"hostnames": ["74.77.246.170.net-uno.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.75.107.127",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.75.107.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 90,
			"totalReports": 25,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-03T01:30:32+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 16
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 10
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 9,
					"name": "Proxy abierto",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.235.232",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 90,
			"totalReports": 25,
			"numDistinctUsers": 15,
			"lastReportedAt": "2026-10-03T09:30:33+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 14
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 9
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.235.115",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.235.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 90,
			"totalReports": 21,
			"numDistinctUsers": 18,
			"lastReportedAt": "2026-09-29T10:40:55+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 15
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.196",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 90,
			"totalReports": 21,
			"numDistinctUsers": 15,
			"lastReportedAt": "2026-10-01T08:28:10+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 14
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.205",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 89,
			"totalReports": 33,
			"numDistinctUsers": 15,
			"lastReportedAt": "2026-10-01T03:30:28+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 17
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.193",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 89,
			"totalReports": 20,
			"numDistinctUsers": 15,
			"lastReportedAt": "2026-10-01T03:30:28+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 13
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.96.69.146",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "186.96.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data C.A.",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 88,
			"totalReports": 22,
			"numDistinctUsers": 19,
			"lastReportedAt": "2026-10-02T07:03:49+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 17
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.120.64",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.120.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 87,
			"totalReports": 58,
			"numDistinctUsers": 18,
			"lastReportedAt": "2026-10-03T16:05:12+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 44
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 18
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				}
			],
			"hostnames": ["64.120.153.190.net-uno.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "143.255.85.204",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "143.255.85.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 87,
			"totalReports": 35,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-09-27T04:10:01+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 25
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 14
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 12
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["ip-143-255-85-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.128.91",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.128.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 87,
			"totalReports": 28,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-09-29T11:29:27+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 21
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 8
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.200",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 87,
			"totalReports": 19,
			"numDistinctUsers": 15,
			"lastReportedAt": "2026-10-01T14:30:28+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 14
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.85",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 86,
			"totalReports": 41,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-09-30T06:18:14+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 17
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 14
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 10
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.248.144",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.248.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 86,
			"totalReports": 37,
			"numDistinctUsers": 26,
			"lastReportedAt": "2026-09-27T01:21:30+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 20
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 11
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 9
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.82.153.180",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.82.128.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 86,
			"totalReports": 36,
			"numDistinctUsers": 21,
			"lastReportedAt": "2026-10-03T01:15:44+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 23
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 10
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 8
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.175",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 86,
			"totalReports": 32,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-02T06:10:00+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 20
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 12
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 10
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.37",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 85,
			"totalReports": 27,
			"numDistinctUsers": 16,
			"lastReportedAt": "2026-10-03T07:04:15+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 14
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.195",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 85,
			"totalReports": 22,
			"numDistinctUsers": 14,
			"lastReportedAt": "2026-10-03T00:25:35+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 14
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.107",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 85,
			"totalReports": 11,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-10-04T01:31:11+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 1
				},
				{
					"id": 6,
					"name": "Ping of Death",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.229",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 84,
			"totalReports": 28,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T14:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "170.246.77.50",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "170.246.77.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 84,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-05T06:03:04+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": ["cclu.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.224",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 82,
			"totalReports": 20,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T03:02:08+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.242.201",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 82,
			"totalReports": 20,
			"numDistinctUsers": 15,
			"lastReportedAt": "2026-10-03T23:41:49+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 12
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 6
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.250",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 81,
			"totalReports": 23,
			"numDistinctUsers": 18,
			"lastReportedAt": "2026-10-04T01:25:02+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.192",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 81,
			"totalReports": 19,
			"numDistinctUsers": 14,
			"lastReportedAt": "2026-09-29T17:33:24+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 12
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.31.168",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 81,
			"totalReports": 18,
			"numDistinctUsers": 15,
			"lastReportedAt": "2026-10-01T18:11:53+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.172",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 79,
			"totalReports": 19,
			"numDistinctUsers": 13,
			"lastReportedAt": "2026-09-28T23:45:17+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 12,
					"name": "Blog spam",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.235.237",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 79,
			"totalReports": 17,
			"numDistinctUsers": 12,
			"lastReportedAt": "2026-10-03T20:17:14+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 8
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.206",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 79,
			"totalReports": 16,
			"numDistinctUsers": 12,
			"lastReportedAt": "2026-10-01T03:30:28+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 12
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.88",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 78,
			"totalReports": 34,
			"numDistinctUsers": 21,
			"lastReportedAt": "2026-09-25T03:34:57+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 20
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.96",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 78,
			"totalReports": 29,
			"numDistinctUsers": 22,
			"lastReportedAt": "2026-10-04T00:43:39+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 11
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 10
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 9
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 13,
					"name": "IP VPN",
					"count": 1
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.243.59",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.243.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 78,
			"totalReports": 15,
			"numDistinctUsers": 11,
			"lastReportedAt": "2026-09-30T06:30:32+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 6
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.238.18",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.238.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 78,
			"totalReports": 11,
			"numDistinctUsers": 9,
			"lastReportedAt": "2026-10-04T05:31:25+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.54.129",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 77,
			"totalReports": 21,
			"numDistinctUsers": 13,
			"lastReportedAt": "2026-10-01T03:58:10+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 15
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.133",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 76,
			"totalReports": 34,
			"numDistinctUsers": 20,
			"lastReportedAt": "2026-09-23T01:23:14+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 14
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 10
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 9
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.27.90",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporacion Digitel C.A.",
			"domain": "digitel.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 76,
			"totalReports": 33,
			"numDistinctUsers": 17,
			"lastReportedAt": "2026-09-29T03:57:15+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 29
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 12
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 11
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.194",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 75,
			"totalReports": 17,
			"numDistinctUsers": 11,
			"lastReportedAt": "2026-10-04T00:44:40+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 5
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.232.214",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.232.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 74,
			"totalReports": 15,
			"numDistinctUsers": 11,
			"lastReportedAt": "2026-10-02T14:56:14+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 12
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-232-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.142.102.0",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "190.142.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 73,
			"totalReports": 36,
			"numDistinctUsers": 10,
			"lastReportedAt": "2026-10-03T14:58:37+00:00",
			"categories": [
				{
					"id": 21,
					"name": "Ataque web",
					"count": 22
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 16
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 13
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 12
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.242.198",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.242.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 73,
			"totalReports": 34,
			"numDistinctUsers": 12,
			"lastReportedAt": "2026-10-04T00:02:34+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 22
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 10
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-242-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.96.69.145",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "186.96.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data C.A.",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 73,
			"totalReports": 27,
			"numDistinctUsers": 17,
			"lastReportedAt": "2026-10-04T05:41:26+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 14
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.73.21.186",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.73.0.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 73,
			"totalReports": 20,
			"numDistinctUsers": 16,
			"lastReportedAt": "2026-09-13T10:45:06+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 11
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 9
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 9
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": ["190-73-21-186-chc-00-p69.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.31.26",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 72,
			"totalReports": 21,
			"numDistinctUsers": 12,
			"lastReportedAt": "2026-09-12T06:55:11+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 14
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 13
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 12
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 8
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.8.164.108",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.8.164.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 71,
			"totalReports": 33,
			"numDistinctUsers": 17,
			"lastReportedAt": "2026-10-04T00:58:01+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 13
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 13
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 13
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 9
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.248.152",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.248.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 71,
			"totalReports": 22,
			"numDistinctUsers": 11,
			"lastReportedAt": "2026-09-30T02:24:58+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 13
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 9
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 8
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "82.86.133.88",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "82.86.132.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Telecom Castilla La Mancha SA",
			"domain": "telecomclm.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 71,
			"totalReports": 15,
			"numDistinctUsers": 11,
			"lastReportedAt": "2026-09-15T13:36:20+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 11
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 3
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.54.45",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 71,
			"totalReports": 11,
			"numDistinctUsers": 10,
			"lastReportedAt": "2026-10-01T07:00:52+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.239",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 70,
			"totalReports": 18,
			"numDistinctUsers": 10,
			"lastReportedAt": "2026-10-04T00:58:17+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["host-190-89-29-239.fibextelecom.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.239.26",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 70,
			"totalReports": 18,
			"numDistinctUsers": 9,
			"lastReportedAt": "2026-09-30T15:36:50+00:00",
			"categories": [
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 12
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 9,
					"name": "Proxy abierto",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.227",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 70,
			"totalReports": 14,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T20:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.103.29.62",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 69,
			"totalReports": 16,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-10-02T04:46:23+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 14
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.111",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 69,
			"totalReports": 16,
			"numDistinctUsers": 13,
			"lastReportedAt": "2026-09-10T00:12:45+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 10
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.230.209",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.230.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 69,
			"totalReports": 12,
			"numDistinctUsers": 11,
			"lastReportedAt": "2026-09-28T00:15:05+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.225",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 68,
			"totalReports": 17,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T14:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "200.8.235.231",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 68,
			"totalReports": 14,
			"numDistinctUsers": 10,
			"lastReportedAt": "2026-10-03T00:30:29+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 6
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.96.66.249",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "186.96.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data C.A.",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 67,
			"totalReports": 12,
			"numDistinctUsers": 10,
			"lastReportedAt": "2026-10-02T01:11:28+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.82.153.187",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.82.128.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 67,
			"totalReports": 9,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-09-29T11:25:24+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.235.241",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 66,
			"totalReports": 19,
			"numDistinctUsers": 10,
			"lastReportedAt": "2026-10-03T11:00:12+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 12
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 8
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.239.30",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 66,
			"totalReports": 3,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-11T02:29:00+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.230",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 65,
			"totalReports": 15,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T20:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.3",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 65,
			"totalReports": 12,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-09-22T19:20:17+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": ["host-190-89-29-3.fibextelecom.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.230.208",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.230.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 64,
			"totalReports": 13,
			"numDistinctUsers": 11,
			"lastReportedAt": "2026-09-30T23:26:58+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 11
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.239.29",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 64,
			"totalReports": 4,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-09-30T14:50:28+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.209",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 63,
			"totalReports": 20,
			"numDistinctUsers": 16,
			"lastReportedAt": "2026-09-29T23:11:15+00:00",
			"categories": [
				{
					"id": 22,
					"name": "SSH",
					"count": 12
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 10
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.30.34",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.30.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 63,
			"totalReports": 14,
			"numDistinctUsers": 10,
			"lastReportedAt": "2026-09-24T13:50:43+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.239.58",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 63,
			"totalReports": 10,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-09-29T20:28:33+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.248.145",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.248.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 62,
			"totalReports": 13,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-10-04T03:04:14+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.96.67.27",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "186.96.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "PUBLICACIONES Y EVENTOS LATAM, SA",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 62,
			"totalReports": 10,
			"numDistinctUsers": 8,
			"lastReportedAt": "2026-09-16T00:07:59+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.23",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 61,
			"totalReports": 14,
			"numDistinctUsers": 9,
			"lastReportedAt": "2026-10-04T04:02:12+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.54.46",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 61,
			"totalReports": 7,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-10-01T10:54:25+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.110",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 61,
			"totalReports": 6,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-09-19T01:03:47+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.235.244",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 60,
			"totalReports": 13,
			"numDistinctUsers": 8,
			"lastReportedAt": "2026-10-03T00:59:09+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.83.194",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CABLE CENTRO SUR SEDE GUACA",
			"domain": "digitel.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 60,
			"totalReports": 11,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-10-03T15:16:56+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 9
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.73.22.24",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.73.0.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 60,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-28T04:30:54+00:00",
			"categories": [],
			"hostnames": ["190-73-22-24-chc-00-p69.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.251.226",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.251.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 59,
			"totalReports": 12,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-09-29T06:26:49+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 1
				},
				{
					"id": 6,
					"name": "Ping of Death",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 16,
					"name": "Inyección SQL",
					"count": 1
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 23,
					"name": "IoT dirigido",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.6.232",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.6.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 59,
			"totalReports": 7,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-09-29T00:02:45+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": ["host-190-153-6-232.NET-UNO.NET"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.49",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 58,
			"totalReports": 21,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T16:44:28+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.36",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 58,
			"totalReports": 12,
			"numDistinctUsers": 9,
			"lastReportedAt": "2026-10-04T00:57:32+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.8.235.249",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 58,
			"totalReports": 12,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-10-03T00:24:37+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.24",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 57,
			"totalReports": 17,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-02T07:25:48+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.232.210",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.232.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 57,
			"totalReports": 7,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-09-29T13:24:41+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-232-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.239.59",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 57,
			"totalReports": 3,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-09-20T08:54:09+00:00",
			"categories": [
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.50",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 56,
			"totalReports": 18,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-27T03:16:42+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "200.8.235.248",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "200.8.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 56,
			"totalReports": 15,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-09-30T12:32:03+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 13
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.228",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 56,
			"totalReports": 13,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T17:00:07+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.199.186.222",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.199.160.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 56,
			"totalReports": 7,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-30T02:16:47+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 7
				}
			],
			"hostnames": ["190-199-186-222.pod-00-p69.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.243.65.37",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.243.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 55,
			"totalReports": 30,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-10-03T22:30:05+00:00",
			"categories": [{
				"id": 22,
				"name": "SSH",
				"count": 30
			}],
			"hostnames": ["201-243-65-37-bto-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.15",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 55,
			"totalReports": 16,
			"numDistinctUsers": 9,
			"lastReportedAt": "2026-10-04T03:48:27+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 12
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.243.109.26",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.243.96.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 55,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-09-11T04:15:57+00:00",
			"categories": [],
			"hostnames": ["201-243-109-26-chc-00-p67.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.251",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 54,
			"totalReports": 16,
			"numDistinctUsers": 13,
			"lastReportedAt": "2026-10-03T01:28:45+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 7
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.24.39.131",
			"isp": "Movistar",
			"asn": 6306,
			"org": "TELEFONICA VENEZOLANA, C.A.",
			"prefix": "186.24.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Suvalcar C.A.",
			"domain": "telefonica.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 54,
			"totalReports": 8,
			"numDistinctUsers": 8,
			"lastReportedAt": "2026-09-27T23:15:20+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 3
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["186-24-39-131.static.telcel.net.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.241.202",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.241.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 54,
			"totalReports": 8,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-09-30T12:05:38+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 12,
					"name": "Blog spam",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "82.86.132.96",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "82.86.132.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Telecom Castilla La Mancha SA",
			"domain": "telecomclm.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 54,
			"totalReports": 6,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-09-22T04:58:57+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "143.255.85.198",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "143.255.85.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 54,
			"totalReports": 3,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-01T15:13:12+00:00",
			"categories": [{
				"id": 14,
				"name": "Escaneo de puertos",
				"count": 2
			}, {
				"id": 19,
				"name": "Bot web malicioso",
				"count": 1
			}],
			"hostnames": ["ip-143-255-85-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.29",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 53,
			"totalReports": 14,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-02T08:43:20+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.248",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 53,
			"totalReports": 14,
			"numDistinctUsers": 9,
			"lastReportedAt": "2026-10-02T06:51:21+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 17,
					"name": "Spoofing",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.239.27",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 53,
			"totalReports": 9,
			"numDistinctUsers": 5,
			"lastReportedAt": "2026-09-29T16:05:43+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "45.186.208.70",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "45.186.208.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 52,
			"totalReports": 13,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-09-29T02:21:05+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 12
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.104",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 52,
			"totalReports": 10,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-10-04T00:35:28+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.226",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 51,
			"totalReports": 15,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T04:54:12+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.239.25",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 51,
			"totalReports": 8,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-10-03T01:29:11+00:00",
			"categories": [
				{
					"id": 21,
					"name": "Ataque web",
					"count": 4
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 12,
					"name": "Blog spam",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.142.194.230",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "190.142.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 51,
			"totalReports": 3,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-08T12:53:49+00:00",
			"categories": [{
				"id": 18,
				"name": "Fuerza bruta",
				"count": 3
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.239.24",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 51,
			"totalReports": 2,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-27T18:39:13+00:00",
			"categories": [
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.142.111.156",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "190.142.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 50,
			"totalReports": 11,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-09-23T01:24:17+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 4
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.135",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 50,
			"totalReports": 7,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-09-30T05:10:02+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 2
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.26",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 49,
			"totalReports": 16,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T23:55:21+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.30",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 49,
			"totalReports": 12,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T14:14:11+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "186.96.67.26",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "186.96.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "PUBLICACIONES Y EVENTOS LATAM, SA",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 49,
			"totalReports": 10,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-09-30T00:21:03+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.120.253.132",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.120.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 49,
			"totalReports": 10,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-09-30T00:34:23+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.232.213",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.232.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 49,
			"totalReports": 8,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-10-01T00:12:33+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-232-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.233.147",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.233.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 49,
			"totalReports": 4,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-10-03T21:56:48+00:00",
			"categories": [
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": ["ip-190-97-233-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.142.102.35",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "190.142.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 48,
			"totalReports": 7,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-09-11T04:13:00+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 30,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.108",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 48,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-09-02T04:23:01+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.232",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 47,
			"totalReports": 13,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-10-03T04:28:33+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": ["host-190-89-29-232.fibextelecom.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.106",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 46,
			"totalReports": 10,
			"numDistinctUsers": 8,
			"lastReportedAt": "2026-10-04T02:31:18+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.241.50",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.241.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 46,
			"totalReports": 5,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-09-30T04:04:29+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.132.208",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.132.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 46,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-09-03T10:25:09+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.234",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 45,
			"totalReports": 13,
			"numDistinctUsers": 7,
			"lastReportedAt": "2026-10-04T01:24:11+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 12,
					"name": "Blog spam",
					"count": 2
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 2
				}
			],
			"hostnames": ["host-190-89-29-234.fibextelecom.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.2",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 45,
			"totalReports": 10,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-10-04T00:36:17+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": ["host-190-89-29-2.fibextelecom.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.103.31.24",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.103.31.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 45,
			"totalReports": 6,
			"numDistinctUsers": 5,
			"lastReportedAt": "2026-09-08T02:19:14+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.2",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 44,
			"totalReports": 10,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T14:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.25",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 44,
			"totalReports": 10,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-29T01:20:30+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.66",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 44,
			"totalReports": 5,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-02T00:00:39+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": ["host-190-89-29-66.fibextelecom.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.114.241.147",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "190.114.240.0/21",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data C.A.",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 44,
			"totalReports": 2,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-27T14:15:19+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.128.28",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.128.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 44,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-13T01:59:47+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.207.219.72",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.207.216.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 44,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-09-03T13:23:43+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.173.221",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.172.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 43,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-26T22:07:52+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.192",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 42,
			"totalReports": 13,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-23T10:47:43+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.15",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 42,
			"totalReports": 7,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T01:53:47+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.239.31",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 42,
			"totalReports": 6,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-10-01T00:14:01+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.247.61",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.247.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 42,
			"totalReports": 2,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-30T12:05:38+00:00",
			"categories": [{
				"id": 14,
				"name": "Escaneo de puertos",
				"count": 2
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.31",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 41,
			"totalReports": 9,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-01T01:16:24+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.107",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 41,
			"totalReports": 8,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-10-02T18:22:12+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 5
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.184.209",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.184.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 41,
			"totalReports": 4,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-10-04T05:25:56+00:00",
			"categories": [{
				"id": 14,
				"name": "Escaneo de puertos",
				"count": 4
			}, {
				"id": 15,
				"name": "Hacking",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.239.17",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 41,
			"totalReports": 3,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-30T04:04:29+00:00",
			"categories": [{
				"id": 14,
				"name": "Escaneo de puertos",
				"count": 3
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.96.69.147",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "186.96.64.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Gold Data C.A.",
			"domain": "golddata.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 41,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-10-01T02:45:07+00:00",
			"categories": [
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.73.26.147",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.73.0.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 41,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-26T09:30:50+00:00",
			"categories": [],
			"hostnames": ["190-73-26-147-chc-00-p69.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.16",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 40,
			"totalReports": 6,
			"numDistinctUsers": 5,
			"lastReportedAt": "2026-10-03T03:16:32+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 11,
					"name": "Email spam",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "82.86.132.148",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "82.86.132.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Telecom Castilla La Mancha SA",
			"domain": "telecomclm.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 40,
			"totalReports": 4,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-30T04:04:12+00:00",
			"categories": [{
				"id": 14,
				"name": "Escaneo de puertos",
				"count": 3
			}, {
				"id": 19,
				"name": "Bot web malicioso",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.21",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 39,
			"totalReports": 10,
			"numDistinctUsers": 8,
			"lastReportedAt": "2026-10-02T01:09:51+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 5
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.244",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 39,
			"totalReports": 5,
			"numDistinctUsers": 5,
			"lastReportedAt": "2026-09-29T15:35:19+00:00",
			"categories": [
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.209.114.164",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.209.96.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 39,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-29T14:08:52+00:00",
			"categories": [],
			"hostnames": ["201-209-114-164-chc-00-p64.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.0",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 38,
			"totalReports": 9,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T00:07:55+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.231.249",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 38,
			"totalReports": 9,
			"numDistinctUsers": 6,
			"lastReportedAt": "2026-09-30T03:19:56+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 7
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 2
				},
				{
					"id": 12,
					"name": "Blog spam",
					"count": 1
				},
				{
					"id": 10,
					"name": "Web spam",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.27",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 38,
			"totalReports": 8,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-27T11:24:24+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.249",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 38,
			"totalReports": 8,
			"numDistinctUsers": 5,
			"lastReportedAt": "2026-09-30T07:18:02+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.129.89",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.128.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 38,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-09-04T00:16:07+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.17",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 37,
			"totalReports": 10,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-22T03:11:08+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.67",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 37,
			"totalReports": 9,
			"numDistinctUsers": 5,
			"lastReportedAt": "2026-09-26T22:05:44+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				}
			],
			"hostnames": ["host-190-89-29-67.fibextelecom.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.73.27.10",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.73.0.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 37,
			"totalReports": 3,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-20T15:59:52+00:00",
			"categories": [{
				"id": 18,
				"name": "Fuerza bruta",
				"count": 3
			}, {
				"id": 22,
				"name": "SSH",
				"count": 3
			}],
			"hostnames": ["190-73-27-10-chc-00-p69.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.229",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 36,
			"totalReports": 9,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-04T00:10:42+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 8
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.247",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 36,
			"totalReports": 8,
			"numDistinctUsers": 5,
			"lastReportedAt": "2026-09-28T22:14:46+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.28",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 36,
			"totalReports": 7,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-25T22:32:15+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.239.57",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.239.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 36,
			"totalReports": 3,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-25T00:17:36+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.128",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 16,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T03:43:57+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.4",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 11,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T14:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.240.165.85",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-01T15:06:22+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.133",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 4,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-01T00:00:59+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.72.18.252",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.72.0.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 3,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-30T04:04:29+00:00",
			"categories": [{
				"id": 14,
				"name": "Escaneo de puertos",
				"count": 3
			}],
			"hostnames": ["190-72-18-252-chc-00-p68.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.253.202",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.253.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-04T18:50:37+00:00",
			"categories": [{
				"id": 14,
				"name": "Escaneo de puertos",
				"count": 1
			}, {
				"id": 18,
				"name": "Fuerza bruta",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.162",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-21T04:25:55+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.248.31.5",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.248.0.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-22T20:07:27+00:00",
			"categories": [],
			"hostnames": ["201-248-31-5.bto-03-p67.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.176.172",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.176.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 35,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-11T02:18:43+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.21",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 34,
			"totalReports": 7,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-02T05:10:02+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.248",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 34,
			"totalReports": 7,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T14:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.240.164.71",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.164.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 34,
			"totalReports": 7,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T02:47:00+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.203.68.50",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.203.64.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 34,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-20T13:03:04+00:00",
			"categories": [],
			"hostnames": ["190-203-68-50.bto-03-p64.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.165",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 34,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-20T14:16:49+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.208.179.68",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.208.160.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 34,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-11T07:48:44+00:00",
			"categories": [],
			"hostnames": ["201-208-179-68-chc-00-p65.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.169.7",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.168.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 34,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-09-01T01:06:32+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.120",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 33,
			"totalReports": 7,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-10-04T01:00:18+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.240.164.68",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.164.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 33,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-01T05:41:00+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.240.165.84",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 33,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-29T09:01:28+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "200.109.232.194",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "200.109.232.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 33,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-30T07:25:27+00:00",
			"categories": [
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": ["200.109.232-194.cnt-02.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.172.137",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.172.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 33,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-22T00:05:05+00:00",
			"categories": [
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.164",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 33,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-23T01:48:57+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.18",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 32,
			"totalReports": 12,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-27T11:04:06+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.231.234",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 32,
			"totalReports": 5,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-09-27T12:32:47+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.240.165.91",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 32,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T05:10:27+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "200.75.159.139",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "200.75.159.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 32,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-21T09:49:04+00:00",
			"categories": [],
			"hostnames": ["host-200-75-159-139.net-uno.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "38.248.129.250",
			"isp": "ThunderNET",
			"asn": 272809,
			"org": "THUNDERNET, C.A.",
			"prefix": "38.248.128.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Cogent Communications, LLC",
			"domain": "cogentco.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 32,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-09-01T01:23:00+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.169",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 31,
			"totalReports": 11,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-29T00:10:23+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.246.137",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.246.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 31,
			"totalReports": 10,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-10-01T17:19:37+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 10
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.9",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 31,
			"totalReports": 8,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T01:34:14+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.240.164.70",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.164.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 31,
			"totalReports": 5,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-02T00:13:43+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.121",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 31,
			"totalReports": 5,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-09-28T00:58:01+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.240.165.83",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 31,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T02:59:40+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.231.232",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 31,
			"totalReports": 4,
			"numDistinctUsers": 4,
			"lastReportedAt": "2026-09-25T21:00:06+00:00",
			"categories": [
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 2
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.166",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 31,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-21T06:31:03+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.11",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 30,
			"totalReports": 8,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T14:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.23",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 30,
			"totalReports": 8,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-25T08:10:41+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.240.165.81",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 30,
			"totalReports": 6,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-21T07:25:15+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.57",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 30,
			"totalReports": 6,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-04T00:40:13+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.240.165.243",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 30,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-01T06:17:15+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.5",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 7,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T14:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.3",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 6,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T23:51:05+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.233",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 6,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-09-19T02:53:03+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				}
			],
			"hostnames": ["host-190-89-29-233.fibextelecom.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.132",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 5,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-04T00:48:40+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.239",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 5,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-09-23T19:57:59+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.240.165.92",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-02T02:45:31+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.231.248",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 3,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-30T13:58:07+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 3
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.95.174.38",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "186.95.160.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-09-06T00:04:05+00:00",
			"categories": [],
			"hostnames": ["186-95-174-38.cnt-01-p77.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.167",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 29,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-21T18:31:04+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.13",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 28,
			"totalReports": 7,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T01:54:31+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.89.29.134",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 28,
			"totalReports": 7,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-09-27T00:37:45+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 6
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.240.165.90",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 28,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T16:02:53+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.240.164.65",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.164.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 27,
			"totalReports": 12,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-01T12:06:25+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.32",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 27,
			"totalReports": 11,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-30T02:16:29+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.8",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 27,
			"totalReports": 10,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-04T01:20:41+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.226.194.189",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 27,
			"totalReports": 5,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-28T22:03:04+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.231.231",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 27,
			"totalReports": 4,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-29T04:26:26+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.243",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 27,
			"totalReports": 4,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-26T02:21:44+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 3
			}, {
				"id": 18,
				"name": "Fuerza bruta",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.4.50",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporacion Digitel C.A.",
			"domain": "digitel.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 27,
			"totalReports": 3,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-02T08:00:27+00:00",
			"categories": [{
				"id": 15,
				"name": "Hacking",
				"count": 2
			}, {
				"id": 14,
				"name": "Escaneo de puertos",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.71.154.142",
			"isp": "Movistar",
			"asn": 6306,
			"org": "TELEFONICA VENEZOLANA, C.A.",
			"prefix": "200.71.144.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "TELEFONICA VENEZOLANA, C.A.",
			"domain": "telefonica.com",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 26,
			"totalReports": 28,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-04T00:23:22+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 28
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 28
				},
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 22
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 3
				}
			],
			"hostnames": ["200-71-154-142.static.telcel.net.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.7",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 26,
			"totalReports": 6,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T20:53:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.231.211",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 26,
			"totalReports": 5,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-10-03T00:25:22+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 4
			}, {
				"id": 18,
				"name": "Fuerza bruta",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.241",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 26,
			"totalReports": 5,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-10-04T00:33:31+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "185.226.194.10",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.226.194.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 26,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-03T00:21:34+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.240.165.82",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.165.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 26,
			"totalReports": 4,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-10-02T03:50:26+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "185.240.164.73",
			"isp": "Datcom Services",
			"asn": 272871,
			"org": "DAT-COM SERVICES, C.A.",
			"prefix": "185.240.164.0/24",
			"countryCode": "VE",
			"usageType": "Data Center/Web Hosting/Transit",
			"ispName": "DAT-COM SERVICES, C.A.",
			"domain": "dat-com.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 25,
			"totalReports": 5,
			"numDistinctUsers": null,
			"lastReportedAt": "2026-09-24T21:02:45+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "reportada",
			"windowDays": 30,
			"source": "abuseipdb-check-block",
			"checkOk": true
		},
		{
			"ip": "190.97.231.212",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 25,
			"totalReports": 5,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-10-01T00:23:45+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 5
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.198",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 25,
			"totalReports": 3,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-30T11:58:38+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.129",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 24,
			"totalReports": 3,
			"numDistinctUsers": 3,
			"lastReportedAt": "2026-09-27T00:46:21+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 3
				},
				{
					"id": 20,
					"name": "Host explotado",
					"count": 1
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.12",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 24,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-13T03:46:05+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.85.56",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.85.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 23,
			"totalReports": 8,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-30T02:16:47+00:00",
			"categories": [
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 7
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 7
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 7
				},
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": ["56.85.153.190.net-uno.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.236",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 23,
			"totalReports": 6,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-10-01T00:15:15+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 4
			}, {
				"id": 18,
				"name": "Fuerza bruta",
				"count": 2
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.128",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 23,
			"totalReports": 4,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-26T01:04:00+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 4
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 2
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 2
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.58",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 23,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-31T00:05:51+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.228",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 22,
			"totalReports": 6,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-29T13:55:20+00:00",
			"categories": [
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 5
				},
				{
					"id": 4,
					"name": "Ataque DDoS",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.230",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 22,
			"totalReports": 4,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-10-01T00:43:03+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 4
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.75",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 22,
			"totalReports": 2,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-15T18:12:10+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 2
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.251",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 21,
			"totalReports": 6,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-26T01:39:03+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 6
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.232.193",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.232.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 21,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-28T03:35:42+00:00",
			"categories": [],
			"hostnames": ["ip-190-97-232-0.viginet.com.ve"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.213",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 20,
			"totalReports": 2,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-25T17:48:36+00:00",
			"categories": [{
				"id": 18,
				"name": "Fuerza bruta",
				"count": 1
			}, {
				"id": 19,
				"name": "Bot web malicioso",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.18.234",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.18.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 16,
			"totalReports": 2,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-10-01T00:43:19+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 2
			}, {
				"id": 4,
				"name": "Ataque DDoS",
				"count": 1
			}],
			"hostnames": ["234.18.153.190.net-uno.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.153.19.207",
			"isp": "Netuno",
			"asn": 11562,
			"org": "Net Uno, C.A.",
			"prefix": "190.153.19.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Net Uno, C.A.",
			"domain": "net-uno.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 16,
			"totalReports": 2,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-30T07:25:26+00:00",
			"categories": [
				{
					"id": 15,
					"name": "Hacking",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 1
				},
				{
					"id": 19,
					"name": "Bot web malicioso",
					"count": 1
				}
			],
			"hostnames": ["207.19.153.190.net-uno.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.231.233",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.231.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 15,
			"totalReports": 2,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-21T00:26:44+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 2
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.89.29.122",
			"isp": "Fibex Telecom",
			"asn": 264628,
			"org": "CORPORACION FIBEX TELECOM, C.A.",
			"prefix": "190.89.29.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION FIBEX TELECOM, C.A.",
			"domain": "fibextelecom.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 13,
			"totalReports": 2,
			"numDistinctUsers": 2,
			"lastReportedAt": "2026-09-28T00:10:49+00:00",
			"categories": [{
				"id": 18,
				"name": "Fuerza bruta",
				"count": 1
			}, {
				"id": 19,
				"name": "Bot web malicioso",
				"count": 1
			}],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.97.247.252",
			"isp": "Viginet",
			"asn": 263703,
			"org": "VIGINET C.A",
			"prefix": "190.97.247.0/24",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "VIGINET C.A",
			"domain": "vnet.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 10,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-09T04:18:53+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.249.192.202",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.249.192.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 6,
			"totalReports": 22,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-10-04T00:23:32+00:00",
			"categories": [
				{
					"id": 5,
					"name": "Fuerza bruta FTP",
					"count": 22
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 22
				},
				{
					"id": 22,
					"name": "SSH",
					"count": 22
				}
			],
			"hostnames": ["201-249-192-202.chc-00.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.75.247.56",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "190.75.224.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 3,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-28T00:15:22+00:00",
			"categories": [{
				"id": 19,
				"name": "Bot web malicioso",
				"count": 1
			}],
			"hostnames": ["190-75-247-56-chc-00-p66.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "200.11.241.106",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "200.11.240.0/22",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 1,
			"totalReports": 1,
			"numDistinctUsers": 1,
			"lastReportedAt": "2026-09-18T02:02:48+00:00",
			"categories": [
				{
					"id": 14,
					"name": "Escaneo de puertos",
					"count": 1
				},
				{
					"id": 18,
					"name": "Fuerza bruta",
					"count": 1
				},
				{
					"id": 21,
					"name": "Ataque web",
					"count": 1
				}
			],
			"hostnames": ["200-11-241-106.cnt-02.rai.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "181.208.40.156",
			"isp": "Corporacion Telemic",
			"asn": 21826,
			"org": "Corporación Telemic C.A.",
			"prefix": "181.208.0.0/16",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "Corporación Telemic C.A.",
			"domain": "inter.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 0,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-07-28T07:04:38+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.167.113.69",
			"isp": "Digitel",
			"asn": 27717,
			"org": "Corporacion Digitel C.A.",
			"prefix": "186.167.0.0/17",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CONECTIP, C.A",
			"domain": "digitel.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 0,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-07-21T18:34:32+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.88.21.158",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "186.88.0.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 0,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-07-17T01:36:04+00:00",
			"categories": [],
			"hostnames": ["186-88-21-158-lms-01-p71.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.91.116.174",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "186.91.96.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 0,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-07-21T04:39:12+00:00",
			"categories": [],
			"hostnames": ["186-91-116-174.cnt-01-p72.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "186.94.60.124",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "186.94.32.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 0,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-02T11:31:33+00:00",
			"categories": [],
			"hostnames": ["186-94-60-124.cnt-01-p76.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.52.108.142",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "190.52.96.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION WAVERED DE VENEZUELA, C.A.",
			"domain": "wave.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 0,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-07-25T06:00:06+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "190.52.108.27",
			"isp": "Gold Data",
			"asn": 394684,
			"org": "GOLD DATA USA INC",
			"prefix": "190.52.96.0/20",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CORPORACION WAVERED DE VENEZUELA, C.A.",
			"domain": "wave.com.ve",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 0,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-08-15T15:30:39+00:00",
			"categories": [],
			"hostnames": [],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		},
		{
			"ip": "201.242.76.71",
			"isp": "CANTV",
			"asn": 8048,
			"org": "CANTV Servicios, Venezuela",
			"prefix": "201.242.64.0/19",
			"countryCode": "VE",
			"usageType": "Fixed Line ISP",
			"ispName": "CANTV Servicios, Venezuela",
			"domain": "cantv.net",
			"isWhitelisted": false,
			"isTor": false,
			"abuseConfidenceScore": 0,
			"totalReports": 0,
			"numDistinctUsers": 0,
			"lastReportedAt": "2026-07-13T20:00:59+00:00",
			"categories": [],
			"hostnames": ["201-242-76-71.pod-00-p72.cantv.net"],
			"tier": "alta",
			"windowDays": 90,
			"source": "abuseipdb-check",
			"checkOk": true
		}
	]
};
var BOTNET_CATEGORY_IDS = /* @__PURE__ */ new Set([
	4,
	5,
	14,
	15,
	18,
	19,
	20,
	21,
	22,
	23
]);
var threats = threats_default;
function ispLabel(id) {
	return threats.isps.find((isp) => isp.id === id)?.name ?? id;
}
function formatReports(n) {
	if (n == null) return "—";
	return new Intl.NumberFormat("es-VE").format(n);
}
function formatStamp(iso) {
	if (!iso) return "sin fecha";
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return "sin fecha";
	const y = d.getUTCFullYear();
	const m = String(d.getUTCMonth() + 1).padStart(2, "0");
	return `${String(d.getUTCDate()).padStart(2, "0")}/${m}/${y} ${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")} UTC`;
}
function scoreTone(score) {
	if (score >= 90) return "high";
	if (score >= 50) return "mid";
	return "low";
}
function hottestPrefixes(rows, limit = 6) {
	const map = /* @__PURE__ */ new Map();
	for (const row of rows) {
		if (!row.prefix) continue;
		const cur = map.get(row.prefix) ?? {
			prefix: row.prefix,
			isp: row.isp,
			count: 0,
			maxScore: 0
		};
		cur.count += 1;
		cur.maxScore = Math.max(cur.maxScore, row.abuseConfidenceScore);
		map.set(row.prefix, cur);
	}
	return [...map.values()].sort((a, b) => b.count - a.count || b.maxScore - a.maxScore).slice(0, limit);
}
function categoryTotals(rows, limit = 6) {
	const counts = /* @__PURE__ */ new Map();
	for (const row of rows) for (const cat of row.categories) counts.set(cat.name, (counts.get(cat.name) ?? 0) + cat.count);
	return [...counts.entries()].map(([name, count]) => ({
		name,
		count
	})).sort((a, b) => b.count - a.count).slice(0, limit);
}
var IPV4_RE = /^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
//#endregion
export { formatStamp as a, scoreTone as c, formatReports as i, threats as l, IPV4_RE as n, hottestPrefixes as o, categoryTotals as r, ispLabel as s, BOTNET_CATEGORY_IDS as t };

import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lookup-vZgs9eG1.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({ ip: string().trim().regex(/^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/, "IP IPv4 inválida") });
var lookupIp_createServerFn_handler = createServerRpc({
	id: "e0095e36e61149ec9c90f5dfe2433f2f4e719f096257d3dd72d7fcb423af320d",
	name: "lookupIp",
	filename: "src/lib/lookup.ts"
}, (opts) => lookupIp.__executeServer(opts));
var lookupIp = createServerFn({ method: "POST" }).validator(Input).handler(lookupIp_createServerFn_handler, async ({ data }) => {
	const { checkIp } = await import("./abuseipdb.server-BZzldJkS.mjs");
	return checkIp(data.ip);
});
//#endregion
export { lookupIp_createServerFn_handler };

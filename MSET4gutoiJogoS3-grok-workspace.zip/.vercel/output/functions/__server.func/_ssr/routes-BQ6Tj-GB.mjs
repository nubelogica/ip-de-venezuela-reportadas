import { i as __toESM } from "../_runtime.mjs";
import { a as formatStamp, c as scoreTone, i as formatReports, l as threats, n as IPV4_RE, o as hottestPrefixes, r as categoryTotals, s as ispLabel, t as BOTNET_CATEGORY_IDS } from "./threats-9uujkDr2.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { a as Search, c as Copy, i as ShieldAlert, o as ExternalLink, r as ShieldOff, s as Download, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Trigger, i as Root2, n as Item2, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { t as Root } from "../_libs/radix-ui__react-separator.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BQ6Tj-GB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "border-transparent bg-secondary text-foreground",
		outline: "border-border text-muted-foreground",
		high: "border-transparent bg-destructive/15 text-destructive",
		mid: "border-transparent bg-warn/15 text-warn",
		low: "border-transparent bg-ok/15 text-ok"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm text-sm font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-accent",
			outline: "border border-border bg-transparent hover:bg-accent",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			destructive: "bg-destructive text-destructive-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/70 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl border border-border bg-card p-6 shadow-[0_0_0_1px_rgba(255,255,255,0.04)] duration-250 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-3 right-3 rounded-sm p-2 text-muted-foreground opacity-80 transition-opacity hover:opacity-100 focus-visible:ring-2 focus-visible:ring-ring/50 focus-visible:outline-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Cerrar"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-medium tracking-tight text-foreground", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 min-w-44 overflow-hidden rounded-md border border-border bg-popover p-1 text-popover-foreground shadow-[0_0_0_1px_rgba(255,255,255,0.04)] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-pointer items-center rounded-sm px-3 py-2 text-sm outline-none select-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var Input$1 = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-sm border border-input bg-card px-3 text-sm text-foreground shadow-[0_0_0_1px_transparent] transition-[border-color,box-shadow] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input$1.displayName = "Input";
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
	...props
}));
Separator.displayName = Root.displayName;
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({ ip: string().trim().regex(/^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/, "IP IPv4 inválida") });
var lookupIp = createServerFn({ method: "POST" }).validator(Input).handler(createSsrRpc("e0095e36e61149ec9c90f5dfe2433f2f4e719f096257d3dd72d7fcb423af320d"));
var EXPORT_FORMATS = [
	{
		id: "txt",
		label: "Lista de IPs",
		ext: "txt"
	},
	{
		id: "csv",
		label: "CSV",
		ext: "csv"
	},
	{
		id: "iptables",
		label: "iptables",
		ext: "sh"
	},
	{
		id: "nftables",
		label: "nftables",
		ext: "nft"
	},
	{
		id: "nginx",
		label: "Nginx deny",
		ext: "conf"
	},
	{
		id: "mikrotik",
		label: "MikroTik",
		ext: "rsc"
	}
];
function csvEscape(value) {
	const s = value == null ? "" : String(value);
	if (/[",\n]/.test(s)) return `"${s.replaceAll("\"", "\"\"")}"`;
	return s;
}
function buildBlocklist(rows, format) {
	const ips = rows.map((r) => r.ip);
	switch (format) {
		case "txt": return ips.join("\n") + (ips.length ? "\n" : "");
		case "csv": return [[
			"ip",
			"isp",
			"asn",
			"prefix",
			"score",
			"reports",
			"lastReportedAt",
			"categories",
			"usageType"
		].join(","), ...rows.map((r) => [
			r.ip,
			r.isp,
			r.asn,
			r.prefix ?? "",
			r.abuseConfidenceScore,
			r.totalReports ?? "",
			r.lastReportedAt ?? "",
			r.categories.map((c) => c.name).join("|"),
			r.usageType ?? ""
		].map(csvEscape).join(","))].join("\n") + "\n";
		case "iptables": return "#!/bin/sh\n# Reja VE — bloqueo botnet ISP venezolanas\niptables -N REJA_VE 2>/dev/null || true\n" + ips.map((ip) => `iptables -A REJA_VE -s ${ip} -j DROP`).join("\n") + "\niptables -C INPUT -j REJA_VE 2>/dev/null || iptables -I INPUT -j REJA_VE\n";
		case "nftables": return "#!/usr/sbin/nft -f\nadd table inet reja_ve\nadd chain inet reja_ve input { type filter hook input priority 0; }\n" + ips.map((ip) => `add rule inet reja_ve input ip saddr ${ip} drop`).join("\n") + "\n";
		case "nginx": return ips.map((ip) => `deny ${ip};`).join("\n") + (ips.length ? "\n" : "");
		case "mikrotik": return ips.map((ip) => `/ip firewall address-list add list=reja-ve-botnet address=${ip} comment="AbuseIPDB VE"`).join("\n") + (ips.length ? "\n" : "");
	}
}
function downloadText(filename, content) {
	const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
var SCORE_STEPS = [
	25,
	50,
	75,
	90,
	100
];
function shortIsp(name) {
	return {
		CANTV: "CANTV",
		Digitel: "Digitel",
		Movistar: "Movistar",
		Movilnet: "Movilnet",
		ThunderNET: "Thunder",
		Netuno: "Netuno",
		"Fibex Telecom": "Fibex",
		"Telemic (Inter)": "Inter",
		"Gold Data": "Gold Data",
		"Datcom Services": "Datcom",
		Viginet: "Viginet"
	}[name] ?? name;
}
function scoreVariant(score) {
	const tone = scoreTone(score);
	if (tone === "high") return "high";
	if (tone === "mid") return "mid";
	return "low";
}
async function copyText(label, value) {
	await navigator.clipboard.writeText(value);
	toast.success(label);
}
function Dashboard() {
	const [isp, setIsp] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const [minScore, setMinScore] = (0, import_react.useState)(75);
	const [botnetOnly, setBotnetOnly] = (0, import_react.useState)(true);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [lookup, setLookup] = (0, import_react.useState)("");
	const [looking, setLooking] = (0, import_react.useState)(false);
	const rows = (0, import_react.useMemo)(() => {
		const needle = q.trim().toLowerCase();
		return threats.ips.filter((row) => {
			if (isp !== "all" && row.isp !== isp) return false;
			if (row.abuseConfidenceScore < minScore) return false;
			if (botnetOnly) {
				if (row.categories.length > 0 && !row.categories.some((c) => BOTNET_CATEGORY_IDS.has(c.id))) return false;
			}
			if (!needle) return true;
			return row.ip.includes(needle) || row.isp.toLowerCase().includes(needle) || row.org.toLowerCase().includes(needle) || String(row.asn).includes(needle) || (row.prefix ?? "").includes(needle);
		});
	}, [
		isp,
		q,
		minScore,
		botnetOnly
	]);
	const byIsp = (0, import_react.useMemo)(() => threats.isps.map((item) => ({
		id: item.id,
		name: item.name,
		kind: item.kind,
		asns: item.asns,
		count: rows.filter((r) => r.isp === item.id).length,
		all: threats.ips.filter((r) => r.isp === item.id).length
	})), [rows]);
	const chartData = byIsp.map((item) => ({
		name: shortIsp(item.name),
		count: item.count
	}));
	const prefixes = hottestPrefixes(rows);
	const cats = categoryTotals(rows);
	const generated = formatStamp(threats.generatedAt);
	async function onLookup(e) {
		e.preventDefault();
		const ip = lookup.trim();
		if (!IPV4_RE.test(ip)) {
			toast.error("Escribe una IPv4 válida");
			return;
		}
		setLooking(true);
		try {
			const result = await lookupIp({ data: { ip } });
			if (!result.ok) {
				toast.error(result.error);
				return;
			}
			setSelected(result.row);
			if (!result.inWatchlist) toast.message("IP fuera de las 11 ISP vigiladas");
			else if (result.botnetLikely) toast.success("Reportada con patrón de botnet");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "No se pudo consultar");
		} finally {
			setLooking(false);
		}
	}
	function exportAs(format) {
		if (!rows.length) {
			toast.error("No hay IPs con el filtro actual");
			return;
		}
		downloadText(`reja-ve-botnet.${EXPORT_FORMATS.find((f) => f.id === format).ext}`, buildBlocklist(rows, format));
		toast.success(`Exportadas ${rows.length} IPs`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-[0.18em] text-muted-foreground uppercase",
									children: "AbuseIPDB · Venezuela"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-2 font-sans text-3xl font-medium tracking-tight text-foreground sm:text-4xl",
									children: "Reja VE"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: "IPs maliciosas y botnet reportadas en las 11 ISP que pediste. Lista lista para bloquear."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								onClick: () => copyText("IPs copiadas", rows.map((r) => r.ip).join("\n")),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Copiar IPs"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Exportar bloqueo"] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
								align: "end",
								children: EXPORT_FORMATS.map((fmt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
									onSelect: () => exportAs(fmt.id),
									children: fmt.label
								}, fmt.id))
							})] })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: onLookup,
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input$1, {
							value: lookup,
							onChange: (e) => setLookup(e.target.value),
							placeholder: "Consultar una IP en AbuseIPDB",
							inputMode: "decimal",
							autoComplete: "off",
							"aria-label": "Dirección IP",
							className: "font-mono sm:max-w-sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							variant: "secondary",
							disabled: looking,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {}), looking ? "Consultando…" : "Verificar"]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid grid-cols-2 gap-3 md:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
								label: "IPs visibles",
								value: formatReports(rows.length)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
								label: "Alta confianza",
								value: formatReports(rows.filter((r) => r.tier === "alta").length)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
								label: "Reportes (top)",
								value: formatReports(rows[0]?.totalReports ?? 0),
								hint: rows[0]?.ip
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
								label: "Snapshot",
								value: generated,
								small: true
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium text-foreground",
								children: "ISP vigiladas"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Toque para filtrar"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
								active: isp === "all",
								onClick: () => setIsp("all"),
								count: rows.length,
								children: "Todas"
							}), byIsp.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
								active: isp === item.id,
								onClick: () => setIsp(item.id === isp ? "all" : item.id),
								count: item.count,
								children: item.name
							}, item.id))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "flex flex-col gap-3 rounded-xl bg-card p-4 sm:p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative w-full lg:max-w-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input$1, {
									value: q,
									onChange: (e) => setQ(e.target.value),
									placeholder: "Buscar IP, ASN o prefijo",
									className: "pl-10",
									"aria-label": "Buscar"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: "Confianza mín."
									}),
									SCORE_STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setMinScore(step),
										className: cn("h-11 min-w-11 rounded-sm px-3 font-mono text-sm transition-[background-color,color] duration-150", minScore === step ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"),
										children: step
									}, step)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: botnetOnly ? "default" : "outline",
										onClick: () => setBotnetOnly((v) => !v),
										children: [botnetOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}), "Solo botnet"]
									})
								]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-4 lg:grid-cols-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-card p-4 lg:col-span-3 sm:p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium",
									children: "Volumen por ISP"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: "IPs que pasan el filtro actual"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 h-72",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
										width: "100%",
										height: "100%",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
											data: chartData,
											layout: "vertical",
											margin: {
												top: 4,
												right: 12,
												left: 8,
												bottom: 0
											},
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
													type: "number",
													allowDecimals: false,
													tick: {
														fill: "var(--color-muted-foreground)",
														fontSize: 11
													},
													axisLine: false,
													tickLine: false
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
													type: "category",
													dataKey: "name",
													width: 78,
													tick: {
														fill: "var(--color-muted-foreground)",
														fontSize: 11
													},
													axisLine: false,
													tickLine: false
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
													cursor: { fill: "var(--color-accent)" },
													contentStyle: {
														background: "var(--color-popover)",
														border: "1px solid var(--color-border)",
														borderRadius: 8,
														color: "var(--color-foreground)",
														fontSize: 12
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													dataKey: "count",
													fill: "var(--color-primary)",
													radius: [
														0,
														4,
														4,
														0
													]
												})
											]
										})
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-card p-4 lg:col-span-2 sm:p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium",
									children: "Prefijos calientes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: "/24 o bloques con más IPs reportadas"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 flex flex-col gap-2",
									children: prefixes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "text-sm text-muted-foreground",
										children: "Sin prefijos para este filtro."
									}) : prefixes.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-3 rounded-md bg-secondary px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-sm",
											children: p.prefix
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: ispLabel(p.isp)
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-sm tabular-nums",
											children: p.count
										})]
									}, p.prefix))
								}),
								cats.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-4" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Categorías AbuseIPDB"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-2 flex flex-col gap-1.5",
										children: cats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex justify-between text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono tabular-nums text-muted-foreground",
												children: formatReports(c.count)
											})]
										}, c.name))
									})
								] }) : null
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "text-sm font-medium",
									children: [formatReports(rows.length), " direcciones"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Toque una fila para el detalle"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-col gap-2 md:hidden",
								children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setSelected(row),
									className: "rounded-xl bg-card p-4 text-left transition-[background-color] duration-150 hover:bg-accent",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-sm",
												children: row.ip
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												variant: scoreVariant(row.abuseConfidenceScore),
												children: [row.abuseConfidenceScore, "%"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-xs text-muted-foreground",
											children: [
												ispLabel(row.isp),
												" · ",
												formatReports(row.totalReports),
												" reportes"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 line-clamp-1 text-xs text-muted-foreground",
											children: row.categories.map((c) => c.name).slice(0, 3).join(" · ") || "Sin categoría"
										})
									]
								}, row.ip))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden overflow-x-auto rounded-xl bg-card md:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full min-w-[720px] text-left text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "text-xs text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "border-b border-border",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "IP"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "ISP"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "Score"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "Reportes"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "Actividad"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "Categorías"
												})
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "cursor-pointer border-b border-border/70 transition-colors duration-150 last:border-0 hover:bg-accent",
										onClick: () => setSelected(row),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 font-mono text-xs",
												children: row.ip
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3",
												children: ispLabel(row.isp)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
													variant: scoreVariant(row.abuseConfidenceScore),
													children: [row.abuseConfidenceScore, "%"]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 font-mono tabular-nums",
												children: formatReports(row.totalReports)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-muted-foreground",
												children: formatStamp(row.lastReportedAt)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-muted-foreground",
												children: row.categories.map((c) => c.name).slice(0, 2).join(", ") || "—"
											})
										]
									}, row.ip)) })]
								})
							}),
							rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "rounded-xl bg-card px-4 py-8 text-center text-sm text-muted-foreground",
								children: ["Ninguna IP con este filtro. Baja la confianza o desactiva “solo botnet”.", isp === "Movilnet" ? " Movilnet no tiene IPs con ~100% de confianza en los últimos 90 días." : null]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "text-xs leading-relaxed text-muted-foreground",
						children: [
							"Snapshot ",
							generated,
							". Fuente: API de AbuseIPDB (check + check-block) cruzada con los ASN de CANTV, Digitel, Movistar, Movilnet, ThunderNET, Netuno, Fibex, Telemic (Inter), Gold Data, Datcom y Viginet. Movilnet aparece en cero a este umbral. No bloquee rangos enteros de ISP residenciales: use la lista de IPs."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IpDialog, {
				row: selected,
				onClose: () => setSelected(null)
			})
		]
	});
}
function Kpi({ label, value, hint, small }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-2 font-medium tracking-tight text-foreground", small ? "text-sm leading-snug" : "text-2xl tabular-nums"),
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-xs text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
function FilterChip({ active, onClick, count, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex h-11 items-center gap-2 rounded-full border px-3.5 text-sm transition-[background-color,color,border-color] duration-150", active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:bg-accent"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("font-mono text-xs tabular-nums", active ? "opacity-80" : "text-muted-foreground"),
			children: count
		})]
	});
}
function IpDialog({ row, onClose }) {
	if (!row) return null;
	const abuseUrl = `https://www.abuseipdb.com/check/${row.ip}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!row,
		onOpenChange: (open) => !open && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-mono text-lg",
				children: row.ip
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				ispLabel(row.isp),
				row.asn ? ` · AS${row.asn}` : "",
				row.usageType ? ` · ${row.usageType}` : ""
			] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
						label: "Confianza",
						value: `${row.abuseConfidenceScore}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
						label: "Reportes",
						value: formatReports(row.totalReports)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
						label: "Último",
						value: formatStamp(row.lastReportedAt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
						label: "Prefijo",
						value: row.prefix ?? "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: row.categories.length ? row.categories.slice(0, 8).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					variant: "outline",
					children: [
						c.name,
						" ",
						c.count
					]
				}, c.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: "Sin categorías detalladas"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					onClick: () => copyText("IP copiada", row.ip),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Copiar IP"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: abuseUrl,
						target: "_blank",
						rel: "noreferrer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {}), "AbuseIPDB"]
					})
				})]
			})
		] })
	});
}
function Meta({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-secondary px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 font-mono text-sm",
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {});
}
//#endregion
export { Home as component };

//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CihApBZP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BXf2hn1-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BXf2hn1-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-wuNt55rp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
